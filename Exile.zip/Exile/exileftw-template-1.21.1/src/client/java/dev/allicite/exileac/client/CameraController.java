package dev.allicite.exileac.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * Controls the client camera position/rotation during live spectate mode.
 * When active, overrides the player's camera to follow the target's exact POV.
 *
 * Uses smooth interpolation to avoid jarring snaps between server ticks.
 */
public class CameraController {

    private static boolean active = false;

    // Current target camera state (from server)
    private static double targetX, targetY, targetZ;
    private static float  targetYaw, targetPitch;

    // Smoothed current state
    private static double currentX, currentY, currentZ;
    private static float  currentYaw, currentPitch;

    private static boolean initialized = false;

    public static void activate() { active = true; initialized = false; }

    public static void deactivate() {
        active = false;
        initialized = false;
    }

    public static boolean isActive() { return active; }

    /**
     * Called when a CameraPovPayload arrives from the server.
     * Updates the target position/rotation.
     */
    public static void updateTarget(double x, double y, double z, float yaw, float pitch) {
        targetX = x; targetY = y; targetZ = z;
        targetYaw = yaw; targetPitch = pitch;

        if (!initialized) {
            currentX = x; currentY = y; currentZ = z;
            currentYaw = yaw; currentPitch = pitch;
            initialized = true;
        }
    }

    /**
     * Called every client tick to smooth camera movement.
     * Interpolates toward target position.
     */
    public static void tick() {
        if (!active || !initialized) return;

        float lerpFactor = 0.5f;
        currentX     = lerp(currentX, targetX, lerpFactor);
        currentY     = lerp(currentY, targetY, lerpFactor);
        currentZ     = lerp(currentZ, targetZ, lerpFactor);
        currentYaw   = lerpAngle(currentYaw, targetYaw, lerpFactor);
        currentPitch = (float) lerp(currentPitch, targetPitch, lerpFactor);

        // Apply to player's render properties so camera follows
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        // Override player rotation to match target
        // The camera reads from player.getYaw/getPitch during render
        client.player.setYaw(currentYaw);
        client.player.setPitch(currentPitch);
    }

    public static double getCurrentX() { return currentX; }
    public static double getCurrentY() { return currentY; }
    public static double getCurrentZ() { return currentZ; }
    public static float  getCurrentYaw()   { return currentYaw; }
    public static float  getCurrentPitch() { return currentPitch; }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static float lerpAngle(float a, float b, float t) {
        float diff = b - a;
        while (diff > 180f)  diff -= 360f;
        while (diff < -180f) diff += 360f;
        return a + diff * t;
    }
}
