package dev.allicite.exileac.client;

import dev.allicite.exileac.server.data.ExileFile;
import dev.allicite.exileac.server.data.PlayerRecord;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Side-by-side session comparison view.
 * Rendered in the main viewport when two sessions are loaded.
 * Shows Player A on the left half and Player B on the right half.
 * Synced tick scrubber advances both simultaneously.
 */
public class CompareView {

    private ExileFile sessionA = null;
    private ExileFile sessionB = null;
    private String nameA = "Player A";
    private String nameB = "Player B";
    private int currentTick = 0;

    public void loadA(ExileFile file, String name) { sessionA = file; nameA = name; currentTick = 0; }
    public void loadB(ExileFile file, String name) { sessionB = file; nameB = name; currentTick = 0; }
    public boolean isActive() { return sessionA != null && sessionB != null; }
    public void setTick(int tick) { this.currentTick = tick; }
    public int getMaxTick() {
        int a = sessionA != null ? sessionA.records.size() - 1 : 0;
        int b = sessionB != null ? sessionB.records.size() - 1 : 0;
        return Math.max(a, b);
    }

    public void render(DrawContext ctx, TextRenderer textRenderer,
                       int x, int y, int w, int h) {
        if (!isActive()) return;

        int half = w / 2;
        int divX = x + half;

        // Divider
        ctx.fill(divX, y, divX + 1, y + h, 0xFF1E3A5F);

        // Headers
        renderPanelHeader(ctx, textRenderer, x, y, half, nameA,
                sessionA != null ? sessionA.suspicionLevel : 0);
        renderPanelHeader(ctx, textRenderer, divX + 1, y, half, nameB,
                sessionB != null ? sessionB.suspicionLevel : 0);

        // Data
        if (sessionA != null && currentTick < sessionA.records.size())
            renderSessionData(ctx, textRenderer, x + 4, y + 18, sessionA.records.get(currentTick), sessionA);
        if (sessionB != null && currentTick < sessionB.records.size())
            renderSessionData(ctx, textRenderer, divX + 5, y + 18, sessionB.records.get(currentTick), sessionB);

        // Diff highlights — things that differ significantly between sessions
        if (sessionA != null && sessionB != null
                && currentTick < sessionA.records.size()
                && currentTick < sessionB.records.size()) {
            PlayerRecord ra = sessionA.records.get(currentTick);
            PlayerRecord rb = sessionB.records.get(currentTick);
            renderDiffLine(ctx, textRenderer, x, y + h - 30, w, ra, rb);
        }
    }

    private void renderPanelHeader(DrawContext ctx, TextRenderer tr,
                                   int x, int y, int w, String name, int sus) {
        ctx.fill(x, y, x + w, y + 14, 0xFF161B22);
        String susTag = sus >= 9 ? "§c" : sus >= 7 ? "§6" : sus >= 5 ? "§e" : "§a";
        ctx.drawText(tr, "§f" + name + " " + susTag + sus + "/10", x + 4, y + 3, 0xFFFFFF, false);
    }

    private void renderSessionData(DrawContext ctx, TextRenderer tr,
                                   int x, int y, PlayerRecord rec, ExileFile session) {
        int lh = 11;
        double bps = Math.sqrt(rec.velX * rec.velX + rec.velZ * rec.velZ) * 20.0;

        ctx.drawText(tr, String.format("§7BPS   §f%.2f",  bps),        x, y, 0xFFFFFF, false); y += lh;
        ctx.drawText(tr, String.format("§7VelX  §f%.4f", rec.velX),    x, y, 0xFFFFFF, false); y += lh;
        ctx.drawText(tr, String.format("§7VelY  §f%.4f", rec.velY),    x, y, 0xFFFFFF, false); y += lh;
        ctx.drawText(tr, String.format("§7VelZ  §f%.4f", rec.velZ),    x, y, 0xFFFFFF, false); y += lh;
        ctx.drawText(tr, String.format("§7Yaw   §f%.2f°", rec.yaw),    x, y, 0xFFFFFF, false); y += lh;
        ctx.drawText(tr, String.format("§7Pitch §f%.2f°", rec.pitch),  x, y, 0xFFFFFF, false); y += lh;
        ctx.drawText(tr, String.format("§7HP    §c%.1f§7/§c%.1f",
                rec.health / 2f, rec.maxHealth / 2f),                  x, y, 0xFFFFFF, false); y += lh;

        if (rec.hasCombatEvent) {
            String rc = rec.reachDistance > 3.2f ? "§c" : "§e";
            ctx.drawText(tr, "§7Reach  " + rc + String.format("%.3fb", rec.reachDistance),
                    x, y, 0xFFFFFF, false); y += lh;
            ctx.drawText(tr, String.format("§7Angle  §f%.2f°", rec.angleToTarget),
                    x, y, 0xFFFFFF, false); y += lh;
        }

        y += 4;
        // Variance summary from session
        if (session.variance != null) {
            ExileFile.VarianceSnapshot vs = session.variance;
            ctx.drawText(tr, String.format("§8AvgReach §7%.3f", vs.averageReach), x, y, 0xFFFFFF, false); y += lh;
            ctx.drawText(tr, String.format("§8AimVar   §7%.4f", vs.aimDeltaVariance), x, y, 0xFFFFFF, false);
        }
    }

    private void renderDiffLine(DrawContext ctx, TextRenderer tr,
                                int x, int y, int w,
                                PlayerRecord ra, PlayerRecord rb) {
        ctx.fill(x, y, x + w, y + 1, 0xFF1E3A5F);
        StringBuilder diffs = new StringBuilder("§7Diff: ");

        double bpsA = Math.sqrt(ra.velX * ra.velX + ra.velZ * ra.velZ) * 20.0;
        double bpsB = Math.sqrt(rb.velX * rb.velX + rb.velZ * rb.velZ) * 20.0;
        if (Math.abs(bpsA - bpsB) > 1.0) {
            diffs.append(String.format("§eBPS Δ%.1f  ", Math.abs(bpsA - bpsB)));
        }

        if (ra.hasCombatEvent && rb.hasCombatEvent) {
            float reachDiff = Math.abs(ra.reachDistance - rb.reachDistance);
            if (reachDiff > 0.2f) {
                diffs.append(String.format("§cReach Δ%.3f  ", reachDiff));
            }
        }

        float yawDiff = Math.abs(ra.yaw - rb.yaw);
        if (yawDiff > 10f) {
            diffs.append(String.format("§7Yaw Δ%.1f°  ", yawDiff));
        }

        ctx.drawText(tr, diffs.toString(), x + 4, y + 4, 0xFFFFFF, false);
    }

    public void clear() { sessionA = null; sessionB = null; currentTick = 0; }
}
