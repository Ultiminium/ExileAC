package dev.allicite.exileac.client;

import dev.allicite.exileac.network.ClientPacketHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ExileFTWClient implements ClientModInitializer {

    public static KeyBinding openReviewMenu;
    public static ReviewUI reviewUI;

    @Override
    public void onInitializeClient() {
        openReviewMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.exileftw.open_review",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_SPACE,
            "category.exileftw"
        ));

        ClientPacketHandler.register();
        reviewUI = new ReviewUI();

        // Alt+Space
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Camera controller tick for smooth POV interpolation
            CameraController.tick();

            while (openReviewMenu.wasPressed()) {
                boolean altHeld =
                    InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_ALT) ||
                    InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT);
                if (altHeld) reviewUI.toggle();
            }
        });

        // World render — trajectory, hitboxes, red zones
        WorldRenderEvents.LAST.register(context -> {
            if (reviewUI == null || !reviewUI.isOpen()) return;
            if (!(context.consumers() instanceof VertexConsumerProvider.Immediate immediate)) return;
            reviewUI.getTrajectoryRenderer().render(
                context.matrixStack(),
                immediate,
                context.camera().getPos(),
                context.tickCounter().getTickDelta(true)
            );
        });
    }
}
