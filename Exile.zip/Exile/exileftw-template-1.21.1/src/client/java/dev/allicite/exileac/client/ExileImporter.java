package dev.allicite.exileac.client;

import dev.allicite.exileac.server.data.ExileFile;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Handles reading .exile files from disk on the client side.
 * Files are stored in: .minecraft/exile-replays/
 * Works fully offline — no server connection needed.
 */
public class ExileImporter {

    public static final Path REPLAY_DIR = MinecraftClient.getInstance()
            .runDirectory.toPath().resolve("exile-replays");

    static {
        try { Files.createDirectories(REPLAY_DIR); }
        catch (IOException e) { System.err.println("[ExileFTW] Failed to create exile-replays dir: " + e.getMessage()); }
    }

    /** Save a .exile byte array to disk. Called when server sends an export. */
    public static Path saveReplay(byte[] data, String playerName, long timestamp) throws IOException {
        Files.createDirectories(REPLAY_DIR);
        String filename = sanitize(playerName) + "_" + timestamp + ".exile";
        Path path = REPLAY_DIR.resolve(filename);
        Files.write(path, data, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        return path;
    }

    /** Load a .exile file from disk by path. */
    public static ExileFile loadReplay(Path path) throws IOException {
        byte[] data = Files.readAllBytes(path);
        return ExileFile.deserialize(data);
    }

    /** List all .exile files in the replay directory, newest first. */
    public static List<ReplayEntry> listReplays() {
        List<ReplayEntry> entries = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(REPLAY_DIR, "*.exile")) {
            for (Path p : stream) {
                try {
                    byte[] data = Files.readAllBytes(p);
                    ExileFile file = ExileFile.deserialize(data);
                    entries.add(new ReplayEntry(p, file));
                } catch (IOException e) {
                    // Add a broken entry so the browser can show it
                    entries.add(new ReplayEntry(p, null));
                }
            }
        } catch (IOException e) {
            System.err.println("[ExileFTW] Failed to list replays: " + e.getMessage());
        }
        entries.sort(Comparator.comparingLong((ReplayEntry e) ->
                e.file() != null ? e.file().sessionStartMs : 0L).reversed());
        return entries;
    }

    /** Delete a .exile file from disk. */
    public static boolean deleteReplay(Path path) {
        try { Files.delete(path); return true; }
        catch (IOException e) { return false; }
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }

    public record ReplayEntry(Path path, ExileFile file) {
        public String displayName() {
            if (file == null) return path.getFileName().toString() + " [corrupted]";
            String name = path.getFileName().toString().replace(".exile", "");
            return name;
        }

        public String suspicionText() {
            if (file == null) return "?";
            int s = file.suspicionLevel;
            if (s >= 9) return "§c" + s + "/10";
            if (s >= 7) return "§6" + s + "/10";
            if (s >= 5) return "§e" + s + "/10";
            return "§a" + s + "/10";
        }

        public String serverText() {
            if (file == null) return "Unknown";
            return file.serverName.isEmpty() ? "Unknown" : file.serverName;
        }

        public String dateText() {
            if (file == null) return "";
            java.time.Instant instant = java.time.Instant.ofEpochMilli(file.sessionStartMs);
            java.time.LocalDateTime dt = java.time.LocalDateTime.ofInstant(
                    instant, java.time.ZoneId.systemDefault());
            return String.format("%02d/%02d %02d:%02d",
                    dt.getMonthValue(), dt.getDayOfMonth(),
                    dt.getHour(), dt.getMinute());
        }
    }
}
