package dev.allicite.exileac.client;

import dev.allicite.exileac.server.data.ExileFile;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

import java.util.List;

public class ReplayBrowser {

    private List<ExileImporter.ReplayEntry> entries = List.of();
    private int scroll = 0;
    private int selectedIndex = -1;
    private String searchQuery = "";
    private boolean searchFocused = false;
    private long lastRefresh = 0;
    private ReplayLoadCallback onLoad;

    public interface ReplayLoadCallback {
        void onReplayLoaded(ExileFile file, String displayName);
    }

    public void setOnLoad(ReplayLoadCallback cb) { this.onLoad = cb; }

    public void refresh() {
        entries = ExileImporter.listReplays();
        scroll = 0;
        selectedIndex = -1;
        lastRefresh = System.currentTimeMillis();
    }

    public void render(DrawContext ctx, TextRenderer textRenderer,
                       int x, int y, int w, int h, int mouseX, int mouseY) {
        if (System.currentTimeMillis() - lastRefresh > 5000) refresh();

        int searchY = y + 2;
        ctx.fill(x + 2, searchY, x + w - 2, searchY + 14,
                searchFocused ? 0xFF1E3A5F : 0xFF161B22);
        if (searchFocused) ctx.fill(x + 2, searchY, x + w - 2, searchY + 1, 0xFF58A6FF);
        String searchDisplay = searchQuery.isEmpty() ? "§8Search replays..." : "§f" + searchQuery;
        ctx.drawText(textRenderer, searchDisplay, x + 5, searchY + 3, 0xFFFFFF, false);

        int listY = searchY + 18;
        int entryH = 32;
        List<ExileImporter.ReplayEntry> filtered = getFiltered();

        if (filtered.isEmpty()) {
            ctx.drawText(textRenderer, "§7No replays found", x + 4, listY + 4, 0x555555, false);
            ctx.drawText(textRenderer, "§8Export one from Online tab", x + 4, listY + 15, 0x333333, false);
            return;
        }

        int visibleCount = Math.max(1, (h - 36) / entryH);
        int ey = listY;

        for (int i = scroll; i < filtered.size() && i < scroll + visibleCount; i++) {
            ExileImporter.ReplayEntry entry = filtered.get(i);
            boolean hovered  = mouseX >= x && mouseX <= x + w && mouseY >= ey && mouseY < ey + entryH;
            boolean selected = i == selectedIndex;

            ctx.fill(x, ey, x + w, ey + entryH,
                    selected ? 0xFF1E3A5F : hovered ? 0xFF161B22 : 0xFF0D1117);
            ctx.fill(x, ey + entryH - 1, x + w, ey + entryH, 0xFF1A2030);

            if (entry.file() != null) {
                int susColor = suspicionColor(entry.file().suspicionLevel);
                ctx.fill(x, ey, x + 3, ey + entryH, susColor | 0xFF000000);
            }

            ctx.drawText(textRenderer, "§f" + truncate(entry.displayName(), 18), x + 6, ey + 3, 0xFFFFFF, false);
            ctx.drawText(textRenderer, entry.suspicionText(), x + 6, ey + 13, 0xFFFFFF, false);
            ctx.drawText(textRenderer, "§8" + entry.serverText(), x + 6, ey + 22, 0x555555, false);
            ctx.drawText(textRenderer, "§8" + entry.dateText(), x + w - 50, ey + 22, 0x555555, false);

            if (entry.file() != null)
                ctx.drawText(textRenderer, "§8" + entry.file().records.size() + "t",
                        x + w - 30, ey + 3, 0x444444, false);

            ey += entryH;
        }

        if (filtered.size() > visibleCount) {
            int trackH = h - 36;
            int thumbH = Math.max(20, trackH * visibleCount / filtered.size());
            int thumbY = listY + (trackH - thumbH) * scroll / Math.max(1, filtered.size() - visibleCount);
            ctx.fill(x + w - 3, listY, x + w, listY + trackH, 0xFF1A2030);
            ctx.fill(x + w - 3, thumbY, x + w, thumbY + thumbH, 0xFF58A6FF);
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY,
                                int x, int y, int w, int h, int button) {
        int searchY = y + 2;
        if (mouseY >= searchY && mouseY <= searchY + 14 && mouseX >= x && mouseX <= x + w) {
            searchFocused = true; return true;
        }
        searchFocused = false;

        int listY = y + 20;
        int entryH = 32;
        List<ExileImporter.ReplayEntry> filtered = getFiltered();
        int visibleCount = Math.max(1, (h - 36) / entryH);
        int ey = listY;

        for (int i = scroll; i < filtered.size() && i < scroll + visibleCount; i++) {
            if (mouseY >= ey && mouseY < ey + entryH && mouseX >= x && mouseX <= x + w) {
                if (button == 0) {
                    selectedIndex = i;
                    ExileImporter.ReplayEntry entry = filtered.get(i);
                    if (entry.file() != null && onLoad != null)
                        onLoad.onReplayLoaded(entry.file(), entry.displayName());
                    return true;
                }
                if (button == 1) {
                    ExileImporter.deleteReplay(filtered.get(i).path());
                    refresh(); return true;
                }
            }
            ey += entryH;
        }
        return false;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!searchFocused) return false;
        if (keyCode == 259) { if (!searchQuery.isEmpty()) searchQuery = searchQuery.substring(0, searchQuery.length()-1); return true; }
        if (keyCode == 256) { searchFocused = false; return true; }
        return false;
    }

    public boolean charTyped(char chr) {
        if (!searchFocused) return false;
        if (searchQuery.length() < 30) searchQuery += chr;
        return true;
    }

    public void scroll(int delta) {
        scroll = Math.max(0, Math.min(scroll - delta, Math.max(0, getFiltered().size() - 1)));
    }

    public boolean isSearchFocused() { return searchFocused; }

    private List<ExileImporter.ReplayEntry> getFiltered() {
        if (searchQuery.isEmpty()) return entries;
        String q = searchQuery.toLowerCase();
        return entries.stream()
                .filter(e -> e.displayName().toLowerCase().contains(q)
                        || e.serverText().toLowerCase().contains(q))
                .toList();
    }

    private int suspicionColor(int level) {
        if (level >= 9) return 0xFFFF3333;
        if (level >= 7) return 0xFFFF8800;
        if (level >= 5) return 0xFFFFCC00;
        return 0xFF33DD55;
    }

    private String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max-1)+"…" : s;
    }
}
