package dev.allicite.exileac.client;

import dev.allicite.exileac.server.data.ExileFile;
import dev.allicite.exileac.server.data.PlayerRecord;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * Exports an ExileFile session as a self-contained HTML report.
 * Saved to .minecraft/exile-replays/reports/
 * Can be opened in any browser and shared for ban appeals.
 */
public class ReportExporter {

    public static final Path REPORT_DIR = ExileImporter.REPLAY_DIR.resolve("reports");

    static {
        try { Files.createDirectories(REPORT_DIR); }
        catch (IOException e) { System.err.println("[ExileFTW] Failed to create reports dir"); }
    }

    public static Path exportHtml(ExileFile file, String playerName) throws IOException {
        String filename = sanitize(playerName) + "_" + file.sessionStartMs + "_report.html";
        Path path = REPORT_DIR.resolve(filename);
        String html = buildHtml(file, playerName);
        Files.writeString(path, html, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        return path;
    }

    private static String buildHtml(ExileFile file, String playerName) {
        LocalDateTime dt = LocalDateTime.ofInstant(
                Instant.ofEpochMilli(file.sessionStartMs), ZoneId.systemDefault());
        String dateStr = dt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int sus = file.suspicionLevel;
        String susColor = sus >= 9 ? "#ff3333" : sus >= 7 ? "#ff8800" : sus >= 5 ? "#ffcc00" : "#33dd55";

        StringBuilder combatRows = new StringBuilder();
        int hitCount = 0;
        for (PlayerRecord rec : file.records) {
            if (!rec.hasCombatEvent) continue;
            hitCount++;
            String reachColor = rec.reachDistance > 3.2f ? "#ff4444" :
                                rec.reachDistance > 3.05f ? "#ffaa00" : "#ffffff";
            combatRows.append(String.format(
                "<tr><td>%d</td><td style='color:%s'>%.3f</td><td>%.2f°</td><td>%s</td></tr>\n",
                rec.tick, reachColor, rec.reachDistance, rec.angleToTarget,
                rec.hitRegistered ? "<span style='color:#33dd55'>HIT</span>"
                                  : "<span style='color:#ff4444'>MISS</span>"));
        }

        StringBuilder varianceSection = new StringBuilder();
        if (file.variance != null) {
            ExileFile.VarianceSnapshot vs = file.variance;
            varianceSection.append(String.format("""
                <div class="section">
                <h2>Variance Analysis</h2>
                <table>
                <tr><th>Metric</th><th>Value</th><th>Flag?</th></tr>
                <tr><td>Avg Reach</td><td>%.3fb</td><td>%s</td></tr>
                <tr><td>Max Reach</td><td>%.3fb</td><td>%s</td></tr>
                <tr><td>Hits Above Vanilla Max</td><td>%d / %d</td><td>%s</td></tr>
                <tr><td>Aim Delta Variance</td><td>%.4f°</td><td>%s</td></tr>
                <tr><td>Aim Lock Sequences</td><td>%d</td><td>%s</td></tr>
                <tr><td>Swap Interval Variance</td><td>%.4f ticks</td><td>%s</td></tr>
                <tr><td>CPS Interval Variance</td><td>%.2f ms</td><td>%s</td></tr>
                <tr><td>Packet Jitter</td><td>%.4f ms</td><td>%s</td></tr>
                </table></div>
                """,
                vs.averageReach, flag(vs.averageReach > 3.1f),
                vs.averageReach, flag(vs.averageReach > 3.4f),
                vs.reachSampleCount, vs.reachSampleCount, flag(vs.reachSampleCount > 0 && vs.averageReach > 3.1f),
                vs.aimDeltaVariance, flag(vs.aimDeltaVariance < 0.1f),
                vs.aimLockSequences, flag(vs.aimLockSequences >= 2),
                vs.swapIntervalVariance, flag(vs.swapIntervalVariance < 0.5f),
                vs.cpsIntervalVarianceMs, flag(vs.cpsIntervalVarianceMs < 2.0f),
                vs.cpsIntervalVarianceMs, flag(vs.cpsIntervalVarianceMs < 0.5f)
            ));
        }

        StringBuilder logsSection = new StringBuilder();
        if (!file.serverLogs.isEmpty()) {
            logsSection.append("<div class='section'><h2>Server Warning Log</h2><pre class='log'>");
            for (String log : file.serverLogs) {
                logsSection.append(escapeHtml(log)).append("\n");
            }
            logsSection.append("</pre></div>");
        }

        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <title>ExileFTW Report — %s</title>
            <style>
              body { background: #0d1117; color: #cdd9e5; font-family: 'Consolas', monospace; margin: 0; padding: 20px; }
              h1 { color: #58a6ff; border-bottom: 1px solid #1e3a5f; padding-bottom: 8px; }
              h2 { color: #8b949e; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; margin-top: 24px; }
              .header { display: flex; gap: 32px; margin-bottom: 24px; }
              .stat { background: #161b22; padding: 12px 20px; border-radius: 6px; border: 1px solid #1e3a5f; }
              .stat-label { font-size: 11px; color: #8b949e; margin-bottom: 4px; }
              .stat-value { font-size: 18px; font-weight: bold; }
              .suspicion { color: %s; }
              table { width: 100%%; border-collapse: collapse; margin-top: 8px; font-size: 12px; }
              th { background: #161b22; color: #8b949e; padding: 6px 10px; text-align: left; border: 1px solid #1e3a5f; }
              td { padding: 5px 10px; border: 1px solid #1a2030; }
              tr:nth-child(even) { background: #0d1117; }
              tr:nth-child(odd)  { background: #111827; }
              .section { margin-top: 24px; }
              .log { background: #0a0a0a; padding: 12px; border-radius: 4px; font-size: 11px; color: #8b949e; overflow-x: auto; white-space: pre-wrap; }
              .flag-yes { color: #ff4444; font-weight: bold; }
              .flag-no  { color: #33dd55; }
              .badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; }
            </style>
            </head>
            <body>
            <h1>⚔ ExileFTW Anticheat Report</h1>
            <div class="header">
              <div class="stat"><div class="stat-label">Player</div><div class="stat-value">%s</div></div>
              <div class="stat"><div class="stat-label">Session</div><div class="stat-value" style="font-size:13px">%s</div></div>
              <div class="stat"><div class="stat-label">Server</div><div class="stat-value" style="font-size:13px">%s</div></div>
              <div class="stat"><div class="stat-label">Suspicion Level</div><div class="stat-value suspicion">%d / 10</div></div>
              <div class="stat"><div class="stat-label">Combat Events</div><div class="stat-value">%d</div></div>
              <div class="stat"><div class="stat-label">Ticks Recorded</div><div class="stat-value">%d</div></div>
            </div>
            %s
            <div class="section">
            <h2>Combat Log (%d events)</h2>
            <table>
            <tr><th>Tick</th><th>Reach</th><th>Angle</th><th>Result</th></tr>
            %s
            </table></div>
            %s
            <div style="margin-top:32px;font-size:11px;color:#444">
              Generated by ExileFTW — %s
            </div>
            </body></html>
            """.formatted(
                playerName, susColor,
                playerName, dateStr, file.serverName, sus,
                hitCount, file.records.size(),
                varianceSection,
                hitCount, combatRows,
                logsSection,
                dateStr
            );
    }

    private static String flag(boolean flagged) {
        return flagged ? "<span class='flag-yes'>⚠ FLAGGED</span>"
                       : "<span class='flag-no'>✓ OK</span>";
    }

    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }
}
