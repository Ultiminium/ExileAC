package dev.allicite.exileac.client;

import dev.allicite.exileac.network.ClientPacketHandler;
import dev.allicite.exileac.network.PacketChannel;
import dev.allicite.exileac.server.data.ExileFile;
import dev.allicite.exileac.server.data.PlayerRecord;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Desktop;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

public class ReviewUI extends Screen {

    private static final int SIDEBAR_W = 160;
    private static final int BOTTOM_H  = 120;
    private static final int HEADER_H  = 20;
    private static final int TAB_H     = 16;

    private enum Tab { ONLINE, REPLAYS, COMPARE }
    private Tab activeTab = Tab.ONLINE;

    private boolean open       = false;
    private boolean isLiveMode = false;

    private UUID selectedPlayer   = null;
    private ExileFile loadedSession = null;
    private String loadedReplayName = null;
    private int currentTick = 0;

    private PacketChannel.LiveTickPayload latestLiveTick = null;

    private final List<PlayerEntry> playerEntries = new ArrayList<>();
    private int playerListScroll = 0;

    // Search
    private String searchQuery = "";
    private boolean searchFocused = false;

    private final ReplayBrowser replayBrowser = new ReplayBrowser();
    private final TrajectoryRenderer trajectoryRenderer = new TrajectoryRenderer();
    private final CompareView compareView = new CompareView();

    // Compare mode — loading session A or B
    private boolean compareModeLoadingB = false;

    // Status toast
    private String toastMessage  = null;
    private long   toastTime     = 0;

    public ReviewUI() {
        super(Text.literal("ExileFTW Review"));
        replayBrowser.setOnLoad((file, name) -> {
            if (activeTab == Tab.COMPARE && compareModeLoadingB) {
                compareView.loadB(file, name);
                compareModeLoadingB = false;
                activeTab = Tab.COMPARE;
            } else if (activeTab == Tab.COMPARE) {
                compareView.loadA(file, name);
            } else {
                loadedSession    = file;
                loadedReplayName = name;
                selectedPlayer   = file.playerUUID;
                currentTick      = 0;
                isLiveMode       = false;
                latestLiveTick   = null;
                trajectoryRenderer.loadSession(file);
            }
        });
    }

    public boolean isOpen() { return open; }
    public TrajectoryRenderer getTrajectoryRenderer() { return trajectoryRenderer; }

    public void toggle() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (open) {
            if (isLiveMode) ClientPacketHandler.stopSpectating();
            client.setScreen(null);
            open = false;
        } else {
            open = true;
            client.setScreen(this);
            ClientPacketHandler.requestSuspicionMap();
            replayBrowser.refresh();
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int w = this.width, h = this.height;
        ctx.fill(0, 0, w, h, 0xCC0A0A0A);

        // Header
        ctx.fill(0, 0, w, HEADER_H, 0xFF111827);
        ctx.drawText(textRenderer, "§b§lExileFTW §7Review Tool", 6, 6, 0xFFFFFF, false);
        ctx.drawText(textRenderer, "§7[Alt+Space]", w - 70, 6, 0x888888, false);

        renderTabs(ctx, mouseX, mouseY);

        // Sidebar Background
        ctx.fill(0, HEADER_H + TAB_H, SIDEBAR_W, h - BOTTOM_H, 0xFF0D1117);

        // Logic for tabs
        if (activeTab == Tab.ONLINE) {
            renderSearchBar(ctx, mouseX, mouseY);
            renderPlayerList(ctx, mouseX, mouseY);
        } else if (activeTab == Tab.REPLAYS) {
            replayBrowser.render(ctx, textRenderer,
                0, HEADER_H + TAB_H, SIDEBAR_W,
                h - BOTTOM_H - HEADER_H - TAB_H, mouseX, mouseY);
        } else if (activeTab == Tab.COMPARE) {
            renderCompareSidebar(ctx, mouseX, mouseY);
        }

        renderViewportOverlay(ctx, mouseX, mouseY);
        renderBottomPanels(ctx);

        // Dividers
        ctx.fill(SIDEBAR_W, HEADER_H, SIDEBAR_W + 1, h, 0xFF1E3A5F);
        ctx.fill(0, h - BOTTOM_H, w, h - BOTTOM_H + 1, 0xFF1E3A5F);
        if (activeTab != Tab.COMPARE) {
            int midX = SIDEBAR_W + (w - SIDEBAR_W) / 2;
            ctx.fill(midX, h - BOTTOM_H, midX + 1, h, 0xFF1E3A5F);
        }

        renderToast(ctx);
        super.render(ctx, mouseX, mouseY, delta);
    } // <--- THIS CLOSES THE RENDER METHOD

  @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Empty and closed properly
    } 
private void renderSearchBar(DrawContext ctx, int mouseX, int mouseY) {
        int sy = HEADER_H + TAB_H + 2;
        
        // Draw the background box
        ctx.fill(2, sy, SIDEBAR_W - 2, sy + 14,
                searchFocused ? 0xFF1E3A5F : 0xFF161B22);
        
        // Draw the blue underline if focused
        if (searchFocused) {
            ctx.fill(2, sy, SIDEBAR_W - 2, sy + 1, 0xFF58A6FF);
        }
        
        // Draw the text
        String display = searchQuery.isEmpty() ? "§8Search players..." : "§f" + searchQuery;
        ctx.drawText(textRenderer, display, 6, sy + 3, 0xFFFFFF, false);
    }
    private void renderTabs(DrawContext ctx, int mouseX, int mouseY) {
        // This method starts immediately after
        int tabW = SIDEBAR_W / 3;
        int ty   = HEADER_H;
        String[] labels = {"§7Online", "§7Replays", "§7Compare"};
        Tab[]    tabs   = {Tab.ONLINE, Tab.REPLAYS, Tab.COMPARE};

        for (int i = 0; i < 3; i++) {
            int tx = i * tabW;
            boolean hov = mouseX >= tx && mouseX < tx + tabW && mouseY >= ty && mouseY < ty + TAB_H;
            ctx.fill(tx, ty, tx + tabW, ty + TAB_H,
                    activeTab == tabs[i] ? 0xFF1E3A5F : hov ? 0xFF161B22 : 0xFF0D1117);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(labels[i]), tx + tabW / 2, ty + 4, 0xFFFFFF);
            if (i < 2) ctx.fill(tx + tabW, ty, tx + tabW + 1, ty + TAB_H, 0xFF1E3A5F);
        }
        int activeX = activeTab == Tab.ONLINE ? 0 : activeTab == Tab.REPLAYS ? tabW : tabW * 2;
        ctx.fill(activeX, ty + TAB_H - 2, activeX + tabW, ty + TAB_H, 0xFF58A6FF);
    }

    private void renderPlayerList(DrawContext ctx, int mouseX, int mouseY) {
        int y = HEADER_H + TAB_H + 20; // leave room for search bar
        List<PlayerEntry> filtered = getFilteredPlayers();

        for (int i = playerListScroll; i < filtered.size(); i++) {
            PlayerEntry e = filtered.get(i);
            if (y + 14 > this.height - BOTTOM_H) break;

            boolean hovered  = mouseX < SIDEBAR_W && mouseY >= y && mouseY < y + 14;
            boolean selected = e.uuid().equals(selectedPlayer) && activeTab == Tab.ONLINE;

            ctx.fill(0, y, SIDEBAR_W, y + 14,
                    selected ? 0xFF1E3A5F : hovered ? 0xFF161B22 : 0x00000000);

            int susColor = suspicionColor(e.suspicionLevel());
            ctx.fill(0, y, (int)(3f * e.suspicionLevel() / 10f) + 1, y + 14, susColor | 0xFF000000);
            String tag = e.suspicionLevel() >= 10 ? "§c[!!]" : "§7[" + e.suspicionLevel() + "]";
            ctx.drawText(textRenderer, "§f" + truncate(e.name(), 11), 6, y + 3, 0xFFFFFF, false);
            ctx.drawText(textRenderer, tag, SIDEBAR_W - 30, y + 3, susColor, false);
            y += 14;
        }

        if (filtered.isEmpty()) {
            ctx.drawText(textRenderer, "§7No players found", 6, HEADER_H + TAB_H + 24, 0x555555, false);
        }
    }

    private void renderCompareSidebar(DrawContext ctx, int mouseX, int mouseY) {
        int y = HEADER_H + TAB_H + 6;
        ctx.drawText(textRenderer, "§7Session A:", 6, y, 0x8B949E, false); y += 12;
        String nameA = compareView.isActive() ? "§fLoaded" : "§8None";
        ctx.drawText(textRenderer, nameA, 6, y, 0xFFFFFF, false); y += 14;

        boolean loadAHov = mouseX < SIDEBAR_W && mouseY >= y && mouseY < y + 12;
        ctx.fill(4, y, SIDEBAR_W - 4, y + 12, loadAHov ? 0xFF1E3A5F : 0xFF161B22);
        ctx.drawText(textRenderer, "§7[ Load A from Replays ]", 6, y + 2, 0xFFFFFF, false); y += 16;

        ctx.drawText(textRenderer, "§7Session B:", 6, y, 0x8B949E, false); y += 12;
        String nameB = compareModeLoadingB ? "§eWaiting..." : "§8None";
        ctx.drawText(textRenderer, nameB, 6, y, 0xFFFFFF, false); y += 14;

        boolean loadBHov = mouseX < SIDEBAR_W && mouseY >= y && mouseY < y + 12;
        ctx.fill(4, y, SIDEBAR_W - 4, y + 12, loadBHov ? 0xFF1E3A5F : 0xFF161B22);
        ctx.drawText(textRenderer, "§7[ Load B from Replays ]", 6, y + 2, 0xFFFFFF, false); y += 20;

        if (compareView.isActive()) {
            boolean clearHov = mouseX < SIDEBAR_W && mouseY >= y && mouseY < y + 12;
            ctx.fill(4, y, SIDEBAR_W - 4, y + 12, clearHov ? 0xFF661111 : 0xFF330000);
            ctx.drawText(textRenderer, "§c[ Clear Compare ]", 6, y + 2, 0xFFFFFF, false);
        }
    }

    private void renderViewportOverlay(DrawContext ctx, int mouseX, int mouseY) {
        int vpX = SIDEBAR_W + 4;
        int vpY = HEADER_H + 4;

        // Compare mode — special viewport
        if (activeTab == Tab.COMPARE && compareView.isActive()) {
            compareView.render(ctx, textRenderer,
                SIDEBAR_W + 1, HEADER_H,
                this.width - SIDEBAR_W - 1,
                this.height - HEADER_H - BOTTOM_H);
            // Unified tick scrubber
            renderCompareScrubber(ctx, mouseX, mouseY);
            return;
        }

        if (selectedPlayer == null && loadedSession == null) {
            int cx = SIDEBAR_W + (this.width - SIDEBAR_W) / 2;
            int cy = HEADER_H + (this.height - HEADER_H - BOTTOM_H) / 2;
            ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§7Select a player or load a replay"), cx, cy - 6, 0x555555);
            return;
        }

        if (isLiveMode) {
            ctx.drawText(textRenderer, "§a● LIVE", vpX, vpY, 0xFFFFFF, false);
            boolean stopHov = mouseX >= vpX+50 && mouseX <= vpX+120 && mouseY >= vpY && mouseY <= vpY+12;
            ctx.fill(vpX+50, vpY, vpX+120, vpY+12, stopHov ? 0xFFCC2222 : 0xFF661111);
            ctx.drawText(textRenderer, "§f[ Stop Live ]", vpX+54, vpY+2, 0xFFFFFF, false);
            if (latestLiveTick != null) {
                PacketChannel.LiveTickPayload t = latestLiveTick;
                ctx.drawText(textRenderer, String.format("§7Yaw §f%.2f°", t.yaw()),   vpX, vpY+14, 0xFFFFFF, false);
                ctx.drawText(textRenderer, String.format("§7Pitch §f%.2f°", t.pitch()), vpX, vpY+25, 0xFFFFFF, false);
                double bps = Math.sqrt(t.velX()*t.velX()+t.velZ()*t.velZ())*20.0;
                ctx.drawText(textRenderer, String.format("§7BPS §f%.2f", bps), vpX, vpY+36, 0xFFFFFF, false);
                int sus = t.suspicionLevel();
                if (sus > 0) {
                    ctx.fill(this.width-110, vpY, this.width-4, vpY+14, suspicionColor(sus)|0xBB000000);
                    ctx.drawCenteredTextWithShadow(textRenderer,
                        Text.literal("§lSUSPICION "+sus+"/10"), this.width-57, vpY+3, 0xFFFFFF);
                }
            }
        } else {
            String modeLabel = loadedReplayName != null
                    ? "§7● REPLAY: §f" + truncate(loadedReplayName, 18)
                    : "§7● REPLAY";
            ctx.drawText(textRenderer, modeLabel, vpX, vpY, 0xFFFFFF, false);

            if (activeTab == Tab.ONLINE && selectedPlayer != null) {
                boolean liveHov = mouseX >= vpX+60 && mouseX <= vpX+140 && mouseY >= vpY && mouseY <= vpY+12;
                ctx.fill(vpX+60, vpY, vpX+140, vpY+12, liveHov ? 0xFF22AA22 : 0xFF116611);
                ctx.drawText(textRenderer, "§f[ Go Live ]", vpX+64, vpY+2, 0xFFFFFF, false);
            }

            // Export button
            if (selectedPlayer != null || loadedSession != null) {
                int expX = vpX + 145;
                boolean expHov = mouseX >= expX && mouseX <= expX+80 && mouseY >= vpY && mouseY <= vpY+12;
                ctx.fill(expX, vpY, expX+80, vpY+12, expHov ? 0xFF1E5A8A : 0xFF0D2D47);
                ctx.drawText(textRenderer, "§b[ Export .exile ]", expX+3, vpY+2, 0xFFFFFF, false);

                // HTML report button
                int rptX = expX + 84;
                boolean rptHov = mouseX >= rptX && mouseX <= rptX+80 && mouseY >= vpY && mouseY <= vpY+12;
                ctx.fill(rptX, vpY, rptX+80, vpY+12, rptHov ? 0xFF2D5A1E : 0xFF143010);
                ctx.drawText(textRenderer, "§a[ HTML Report ]", rptX+3, vpY+2, 0xFFFFFF, false);
            }

            if (loadedSession != null && currentTick < loadedSession.records.size()) {
                PlayerRecord rec = loadedSession.records.get(currentTick);
                ctx.drawText(textRenderer, "§7Tick §f"+rec.tick,              vpX, vpY+14, 0xFFFFFF, false);
                ctx.drawText(textRenderer, String.format("§7Yaw §f%.2f°",   rec.yaw),   vpX, vpY+25, 0xFFFFFF, false);
                ctx.drawText(textRenderer, String.format("§7Pitch §f%.2f°", rec.pitch), vpX, vpY+36, 0xFFFFFF, false);
            }

            if (loadedSession != null && loadedSession.suspicionLevel >= 7) {
                ctx.fill(this.width-110, vpY, this.width-4, vpY+14,
                        suspicionColor(loadedSession.suspicionLevel)|0xBB000000);
                ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("§lSUSPICION "+loadedSession.suspicionLevel+"/10"),
                    this.width-57, vpY+3, 0xFFFFFF);
            }

            if (loadedSession != null && !loadedSession.records.isEmpty())
                renderTickScrubber(ctx);
        }
    }

    private void renderCompareScrubber(DrawContext ctx, int mouseX, int mouseY) {
        int maxTick = compareView.getMaxTick();
        if (maxTick <= 0) return;
        int y  = this.height - BOTTOM_H - 18;
        int x1 = SIDEBAR_W + 8, x2 = this.width - 8;
        int w  = x2 - x1;
        ctx.fill(x1, y+5, x2, y+7, 0xFF30363D);
        int prog = (int)(w * ((float) currentTick / maxTick));
        ctx.fill(x1, y+5, x1+prog, y+7, 0xFF9B59B6); // purple for compare mode
        ctx.fill(x1+prog-2, y+3, x1+prog+2, y+9, 0xFFCDD9E5);
        ctx.drawText(textRenderer, "§8"+currentTick+"/"+maxTick, x1, y-8, 0x555555, false);
        ctx.drawText(textRenderer, "§5Compare Mode §8— ◄► arrow keys", x2-130, y-8, 0x555555, false);
    }

    private void renderTickScrubber(DrawContext ctx) {
        int maxTick = loadedSession.records.size()-1;
        if (maxTick <= 0) return;
        int y  = this.height - BOTTOM_H - 18;
        int x1 = SIDEBAR_W + 8, x2 = this.width - 8;
        int w  = x2 - x1;
        ctx.fill(x1, y+5, x2, y+7, 0xFF30363D);
        int prog = (int)(w*((float)currentTick/maxTick));
        ctx.fill(x1, y+5, x1+prog, y+7, 0xFF58A6FF);
        ctx.fill(x1+prog-2, y+3, x1+prog+2, y+9, 0xFFCDD9E5);
        ctx.drawText(textRenderer, "§8"+currentTick+"/"+maxTick, x1, y-8, 0x555555, false);
        ctx.drawText(textRenderer, "§7◄► §8arrow keys", x2-70, y-8, 0x555555, false);
    }

    private void renderBottomPanels(DrawContext ctx) {
        if (activeTab == Tab.COMPARE) return; // compare has its own layout

        int h = this.height, panelY = h - BOTTOM_H;
        int midX = SIDEBAR_W + (this.width - SIDEBAR_W) / 2;

        ctx.fill(SIDEBAR_W, panelY, midX, panelY+14, 0xFF161B22);
        ctx.fill(midX, panelY, this.width, panelY+14, 0xFF161B22);
        ctx.drawText(textRenderer, "§7Player Data",       SIDEBAR_W+4, panelY+4, 0x8B949E, false);
        ctx.drawText(textRenderer, "§7Variance Analysis", midX+4,      panelY+4, 0x8B949E, false);

        int lx = SIDEBAR_W+6, ly = panelY+18, lh = 11;

        if (isLiveMode && latestLiveTick != null) {
            PacketChannel.LiveTickPayload t = latestLiveTick;
            double bps = Math.sqrt(t.velX()*t.velX()+t.velZ()*t.velZ())*20.0;
            ctx.drawText(textRenderer, String.format("§7VelX  §f%.4f", t.velX()), lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7VelY  §f%.4f", t.velY()), lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7VelZ  §f%.4f", t.velZ()), lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7BPS   §f%.2f",  bps),     lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7HP    §c%.1f§7/§c%.1f", t.health()/2f, t.maxHealth()/2f), lx, ly, 0xFFFFFF, false); ly+=lh;
            if (t.hasCombat()) {
                String rc = t.reach() > 3.2f ? "§c" : "§e";
                ctx.drawText(textRenderer, "§7Reach  "+rc+String.format("%.3fb", t.reach()), lx, ly, 0xFFFFFF, false); ly+=lh;
                ctx.drawText(textRenderer, String.format("§7Angle  §f%.3f°", t.angleToTarget()), lx, ly, 0xFFFFFF, false);
            }
            int rx = midX+6, ry = panelY+18;
            ctx.drawText(textRenderer, "§7Suspicion: "+suspicionText(t.suspicionLevel()), rx, ry, 0xFFFFFF, false); ry+=lh;
            ctx.drawText(textRenderer, "§8Analysis every 5 combat events", rx, ry, 0x555555, false);

        } else if (loadedSession != null && currentTick < loadedSession.records.size()) {
            PlayerRecord rec = loadedSession.records.get(currentTick);
            double bps = Math.sqrt(rec.velX*rec.velX+rec.velZ*rec.velZ)*20.0;
            ctx.drawText(textRenderer, String.format("§7VelX  §f%.4f", rec.velX),  lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7VelY  §f%.4f", rec.velY),  lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7VelZ  §f%.4f", rec.velZ),  lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7BPS   §f%.2f",  bps),      lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7Yaw   §f%.3f°", rec.yaw),  lx, ly, 0xFFFFFF, false); ly+=lh;
            ctx.drawText(textRenderer, String.format("§7Pitch §f%.3f°", rec.pitch),lx, ly, 0xFFFFFF, false); ly+=lh;
            if (rec.hasCombatEvent) {
                String rc = rec.reachDistance > 3.2f ? "§c" : "§e";
                ctx.drawText(textRenderer, "§7Reach  "+rc+String.format("%.3fb", rec.reachDistance), lx, ly, 0xFFFFFF, false); ly+=lh;
                ctx.drawText(textRenderer, String.format("§7Angle  §f%.3f°", rec.angleToTarget), lx, ly, 0xFFFFFF, false); ly+=lh;
                ctx.drawText(textRenderer, "§7Hit    "+(rec.hitRegistered?"§aYES":"§cNO"), lx, ly, 0xFFFFFF, false);
            }

            int rx = midX+6, ry = panelY+18;
            ctx.drawText(textRenderer, "§7Suspicion: "+suspicionText(loadedSession.suspicionLevel), rx, ry, 0xFFFFFF, false); ry+=lh;
            ctx.drawText(textRenderer, "§8────────────────────────", rx, ry, 0x333333, false); ry+=lh;
            if (loadedSession.variance != null) {
                ExileFile.VarianceSnapshot vs = loadedSession.variance;
                String rFlag = vs.averageReach > 3.1f ? " §c←" : "";
                ctx.drawText(textRenderer, String.format("§7AvgReach §f%.3fb%s", vs.averageReach, rFlag), rx, ry, 0xFFFFFF, false); ry+=lh;
                ctx.drawText(textRenderer, String.format("§7AimVar   §f%.4f", vs.aimDeltaVariance), rx, ry, 0xFFFFFF, false); ry+=lh;
                ctx.drawText(textRenderer, String.format("§7SwapVar  §f%.4f", vs.swapIntervalVariance), rx, ry, 0xFFFFFF, false); ry+=lh;
                ctx.drawText(textRenderer, String.format("§7CPSVar   §f%.2fms", vs.cpsIntervalVarianceMs), rx, ry, 0xFFFFFF, false);
            } else {
                ctx.drawText(textRenderer, "§8Variance: run analysis first", rx, ry, 0x555555, false);
            }
        }
    }

    private void renderToast(DrawContext ctx) {
        if (toastMessage == null) return;
        if (System.currentTimeMillis() - toastTime > 4000) { toastMessage = null; return; }
        int tw = textRenderer.getWidth(toastMessage) + 10;
        int tx = (this.width - tw) / 2;
        int ty = this.height - BOTTOM_H - 22;
        ctx.fill(tx, ty, tx+tw, ty+13, 0xDD111827);
        ctx.fill(tx, ty, tx+tw, ty+1, 0xFF58A6FF);
        ctx.drawText(textRenderer, toastMessage, tx+5, ty+3, 0xFFFFFF, false);
    }

    // --- Mouse & Keyboard ---

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Tab clicks
        int tabW = SIDEBAR_W / 3;
        if (mouseY >= HEADER_H && mouseY < HEADER_H + TAB_H && mouseX < SIDEBAR_W) {
            if (mouseX < tabW)         { activeTab = Tab.ONLINE;  searchFocused = false; return true; }
            if (mouseX < tabW * 2)     { activeTab = Tab.REPLAYS; replayBrowser.refresh(); return true; }
            if (mouseX < SIDEBAR_W)    { activeTab = Tab.COMPARE; return true; }
        }

        // Search bar
        if (activeTab == Tab.ONLINE && mouseX < SIDEBAR_W) {
            int sy = HEADER_H + TAB_H + 2;
            if (mouseY >= sy && mouseY <= sy + 14) { searchFocused = true; return true; }
            searchFocused = false;
        }

        // Compare sidebar
        if (activeTab == Tab.COMPARE && mouseX < SIDEBAR_W) {
            int y = HEADER_H + TAB_H + 30;
            // Load A
            if (mouseY >= y && mouseY < y + 12) {
                compareModeLoadingB = false; activeTab = Tab.REPLAYS; return true;
            }
            y += 30;
            // Load B
            if (mouseY >= y && mouseY < y + 12) {
                compareModeLoadingB = true; activeTab = Tab.REPLAYS; return true;
            }
            y += 20;
            // Clear
            if (mouseY >= y && mouseY < y + 12) { compareView.clear(); return true; }
            return false;
        }

        // Replay browser
        if (activeTab == Tab.REPLAYS && mouseX < SIDEBAR_W) {
            return replayBrowser.mouseClicked(mouseX, mouseY,
                0, HEADER_H + TAB_H, SIDEBAR_W,
                this.height - BOTTOM_H - HEADER_H - TAB_H, button);
        }

        // Online player list
        if (activeTab == Tab.ONLINE && mouseX < SIDEBAR_W) {
            int y = HEADER_H + TAB_H + 20;
            List<PlayerEntry> filtered = getFilteredPlayers();
            for (int i = playerListScroll; i < filtered.size(); i++) {
                if (mouseY >= y && mouseY < y + 14) { selectPlayer(filtered.get(i).uuid()); return true; }
                y += 14;
            }
        }

        int vpX = SIDEBAR_W + 4, vpY = HEADER_H + 4;

        // Compare tick scrubber
        if (activeTab == Tab.COMPARE && compareView.isActive()) {
            int scrubY = this.height - BOTTOM_H - 18;
            int x1 = SIDEBAR_W + 8, x2 = this.width - 8;
            if (mouseY >= scrubY-2 && mouseY <= scrubY+12 && mouseX >= x1 && mouseX <= x2) {
                float pct = (float)(mouseX - x1) / (x2 - x1);
                currentTick = Math.max(0, Math.min((int)(pct * compareView.getMaxTick()), compareView.getMaxTick()));
                compareView.setTick(currentTick);
                return true;
            }
            return false;
        }

        // Live / Stop / Go Live
        if (selectedPlayer != null) {
            if (isLiveMode) {
                if (mouseX >= vpX+50 && mouseX <= vpX+120 && mouseY >= vpY && mouseY <= vpY+12) { stopLive(); return true; }
            } else if (activeTab == Tab.ONLINE) {
                if (mouseX >= vpX+60 && mouseX <= vpX+140 && mouseY >= vpY && mouseY <= vpY+12) { startLive(); return true; }
            }
        }

        // Export .exile button
        if ((selectedPlayer != null || loadedSession != null) && !isLiveMode) {
            int expX = vpX + 145;
            if (mouseX >= expX && mouseX <= expX+80 && mouseY >= vpY && mouseY <= vpY+12) {
                requestExport(); return true;
            }
            // HTML Report button
            int rptX = expX + 84;
            if (mouseX >= rptX && mouseX <= rptX+80 && mouseY >= vpY && mouseY <= vpY+12) {
                exportHtmlReport(); return true;
            }
        }

        // Tick scrubber
        if (!isLiveMode && loadedSession != null && !loadedSession.records.isEmpty()) {
            int scrubY = this.height - BOTTOM_H - 18;
            int x1 = SIDEBAR_W + 8, x2 = this.width - 8;
            if (mouseY >= scrubY-2 && mouseY <= scrubY+12 && mouseX >= x1 && mouseX <= x2) {
                float pct = (float)(mouseX-x1)/(x2-x1);
                currentTick = Math.max(0, Math.min((int)(pct*(loadedSession.records.size()-1)), loadedSession.records.size()-1));
                trajectoryRenderer.setCurrentTick(currentTick);
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchFocused) {
            if (keyCode == 259 && !searchQuery.isEmpty()) {
                searchQuery = searchQuery.substring(0, searchQuery.length()-1); return true;
            }
            if (keyCode == 256) { searchFocused = false; return true; }
        }
        if (activeTab == Tab.REPLAYS && replayBrowser.keyPressed(keyCode, scanCode, modifiers)) return true;

        if (keyCode == 263) { // LEFT
            currentTick = Math.max(0, currentTick-1);
            if (activeTab == Tab.COMPARE) compareView.setTick(currentTick);
            else if (loadedSession != null) trajectoryRenderer.setCurrentTick(currentTick);
            return true;
        }
        if (keyCode == 262) { // RIGHT
            int max = activeTab == Tab.COMPARE ? compareView.getMaxTick()
                    : loadedSession != null ? loadedSession.records.size()-1 : 0;
            currentTick = Math.min(max, currentTick+1);
            if (activeTab == Tab.COMPARE) compareView.setTick(currentTick);
            else if (loadedSession != null) trajectoryRenderer.setCurrentTick(currentTick);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused && searchQuery.length() < 24) { searchQuery += chr; return true; }
        if (activeTab == Tab.REPLAYS) return replayBrowser.charTyped(chr);
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmt, double vAmt) {
        if (mx < SIDEBAR_W) {
            if (activeTab == Tab.REPLAYS) { replayBrowser.scroll((int)vAmt); return true; }
            playerListScroll = Math.max(0, playerListScroll-(int)vAmt);
            return true;
        }
        return super.mouseScrolled(mx, my, hAmt, vAmt);
    }

    // --- Data callbacks ---

    public void onSuspicionMapReceived(List<PlayerEntry> entries) {
        playerEntries.clear();
        playerEntries.addAll(entries);
        playerEntries.sort((a, b) -> b.suspicionLevel()-a.suspicionLevel());
    }

    public void onSessionDataReceived(ExileFile session) {
        loadedSession    = session;
        loadedReplayName = null;
        currentTick      = 0;
        isLiveMode       = false;
        trajectoryRenderer.loadSession(session);
    }

    public void onLiveSnapshotReceived(ExileFile liveSession) {
        loadedSession = liveSession;
        isLiveMode    = true;
        if (!liveSession.records.isEmpty()) currentTick = liveSession.records.size()-1;
        trajectoryRenderer.loadSession(liveSession);
    }

    public void onLiveTickReceived(PacketChannel.LiveTickPayload payload) {
        latestLiveTick = payload;
    }

    public void onExileExportReceived(byte[] data, UUID playerUUID) {
        try {
            String name = playerEntries.stream()
                    .filter(e -> e.uuid().equals(playerUUID))
                    .map(PlayerEntry::name)
                    .findFirst().orElse(playerUUID.toString().substring(0, 8));
            Path saved = ExileImporter.saveReplay(data, name, System.currentTimeMillis());
            toast("§aSaved: " + saved.getFileName());
            replayBrowser.refresh();
        } catch (IOException e) {
            toast("§cExport failed: " + e.getMessage());
        }
    }

    // --- Internals ---

    private void selectPlayer(UUID uuid) {
        if (isLiveMode) stopLive();
        selectedPlayer   = uuid;
        loadedSession    = null;
        loadedReplayName = null;
        currentTick      = 0;
        latestLiveTick   = null;
        ClientPacketHandler.requestSessions(uuid);
    }

    private void startLive() {
        if (selectedPlayer == null) return;
        isLiveMode = true; latestLiveTick = null;
        ClientPacketHandler.startSpectating(selectedPlayer);
    }

    private void stopLive() {
        isLiveMode = false; latestLiveTick = null;
        ClientPacketHandler.stopSpectating();
    }

    private void requestExport() {
        if (selectedPlayer == null && loadedSession == null) return;
        toast("§7Exporting...");
        if (selectedPlayer != null) ClientPacketHandler.requestExport(selectedPlayer);
    }

    private void exportHtmlReport() {
        if (loadedSession == null) { toast("§cNo session loaded"); return; }
        try {
            String name = loadedReplayName != null ? loadedReplayName
                    : playerEntries.stream()
                        .filter(e -> loadedSession.playerUUID.equals(e.uuid()))
                        .map(PlayerEntry::name).findFirst().orElse("Unknown");
            Path report = ReportExporter.exportHtml(loadedSession, name);
            toast("§aReport saved: " + report.getFileName());
            // Try to open in browser
            try { Desktop.getDesktop().browse(report.toUri()); }
            catch (Exception ignored) {}
        } catch (IOException e) {
            toast("§cReport failed: " + e.getMessage());
        }
    }

    private void toast(String message) {
        toastMessage = message;
        toastTime    = System.currentTimeMillis();
    }

    private List<PlayerEntry> getFilteredPlayers() {
        if (searchQuery.isEmpty()) return playerEntries;
        String q = searchQuery.toLowerCase();
        return playerEntries.stream()
                .filter(e -> e.name().toLowerCase().contains(q)
                        || e.uuid().toString().contains(q)
                        || String.valueOf(e.suspicionLevel()).contains(q))
                .toList();
    }

    @Override public boolean shouldPause()      { return false; }
    @Override public boolean shouldCloseOnEsc() { return true;  }

    private String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max-1)+"…" : s;
    }

    private int suspicionColor(int l) {
        if (l >= 9) return 0xFFFF3333;
        if (l >= 7) return 0xFFFF8800;
        if (l >= 5) return 0xFFFFCC00;
        return 0xFF33DD55;
    }

    private String suspicionText(int l) {
        String c = l >= 9 ? "§c" : l >= 7 ? "§6" : l >= 5 ? "§e" : "§a";
        return c + l + "/10";
    }

    public record PlayerEntry(UUID uuid, String name, int suspicionLevel) {}
}
