package dev.allicite.exileac.client;

import dev.allicite.exileac.server.data.ExileFile;
import dev.allicite.exileac.server.data.PlayerRecord;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Renders the ExileFTW trajectory visualization in-world.
 * Called by GameRendererMixin during the world render pass.
 *
 * What it draws:
 *   WHITE LINE   — traced aim path (yaw/pitch converted to direction vectors per tick)
 *   RED ZONES    — tick ranges where aim-lock pattern was detected (consistent angle delta)
 *   CYAN BOX     — P1 (suspect) hitbox at current tick
 *   YELLOW BOX   — P2 (target) hitbox at current tick
 *   ORANGE BOX   — P2 hitbox at the moment of each flagged hit
 *   TICK LABELS  — N and N+1 tick positions annotated at combat events
 */
public class TrajectoryRenderer {

    private ExileFile session;
    private int currentTick = 0;

    // Pre-computed trajectory points and red zone ranges
    private final List<Vec3d> trajectoryPoints = new ArrayList<>();
    private final List<int[]> redZoneRanges = new ArrayList<>(); // [startTick, endTick]

    private static final float LINE_WIDTH = 1.5f;

    // Standard Minecraft player hitbox: 0.6 wide, 1.8 tall
    private static final double HITBOX_W = 0.6;
    private static final double HITBOX_H = 1.8;

    public void loadSession(ExileFile session) {
        this.session = session;
        this.currentTick = 0;
        rebuildTrajectory();
        detectRedZones();
    }

    public void setCurrentTick(int tick) {
        this.currentTick = tick;
    }

    /**
     * Called by GameRendererMixin during world render.
     * Camera is positioned at P1's eye position for the current tick.
     */
    public void render(MatrixStack matrices, VertexConsumerProvider.Immediate vertexConsumers,
                       Vec3d cameraPos, float tickDelta) {
        if (session == null || session.records.isEmpty()) return;

        VertexConsumer lineConsumer = vertexConsumers.getBuffer(RenderLayer.LINES);
        Matrix4f posMatrix = matrices.peek().getPositionMatrix();

        // --- Draw aim trajectory line ---
        renderTrajectoryLine(lineConsumer, posMatrix, cameraPos);

        // --- Draw red zones (overlaid on trajectory) ---
        renderRedZones(lineConsumer, posMatrix, cameraPos);

        // --- Draw hitboxes at current tick ---
        renderHitboxes(lineConsumer, posMatrix, cameraPos);

        // --- Draw sub-tick aim samples (dots between ticks) ---
        renderSubTickSamples(lineConsumer, posMatrix, cameraPos);

        vertexConsumers.draw();
    }

    private void renderTrajectoryLine(VertexConsumer consumer, Matrix4f mat, Vec3d cam) {
        if (trajectoryPoints.size() < 2) return;

        for (int i = 0; i < trajectoryPoints.size() - 1; i++) {
            Vec3d a = trajectoryPoints.get(i).subtract(cam);
            Vec3d b = trajectoryPoints.get(i + 1).subtract(cam);

            // White, semi-transparent
            addLine(consumer, mat,
                    (float)a.x, (float)a.y, (float)a.z,
                    (float)b.x, (float)b.y, (float)b.z,
                    1f, 1f, 1f, 0.7f);
        }
    }

    private void renderRedZones(VertexConsumer consumer, Matrix4f mat, Vec3d cam) {
        for (int[] range : redZoneRanges) {
            int start = Math.max(0, range[0]);
            int end = Math.min(trajectoryPoints.size() - 1, range[1]);
            for (int i = start; i < end; i++) {
                Vec3d a = trajectoryPoints.get(i).subtract(cam);
                Vec3d b = trajectoryPoints.get(i + 1).subtract(cam);
                // Red, fully opaque
                addLine(consumer, mat,
                        (float)a.x, (float)a.y, (float)a.z,
                        (float)b.x, (float)b.y, (float)b.z,
                        1f, 0.1f, 0.1f, 1f);
            }
        }
    }

    private void renderHitboxes(VertexConsumer consumer, Matrix4f mat, Vec3d cam) {
        if (currentTick >= session.records.size()) return;
        PlayerRecord rec = session.records.get(currentTick);

        // P1 hitbox — cyan
        renderBox(consumer, mat, cam,
                rec.posX - HITBOX_W/2, rec.posY, rec.posZ - HITBOX_W/2,
                rec.posX + HITBOX_W/2, rec.posY + HITBOX_H, rec.posZ + HITBOX_W/2,
                0f, 1f, 1f, 0.8f);

        // P2 hitbox — yellow (if this tick has a combat event with known target position)
        // Target position is reconstructed from records where the target is the attacker
        // (i.e., find the record for targetUUID at this tick)
        if (rec.hasCombatEvent && rec.targetUUID != null) {
            Vec3d targetPos = estimateTargetPos(rec);
            if (targetPos != null) {
                renderBox(consumer, mat, cam,
                        targetPos.x - HITBOX_W/2, targetPos.y, targetPos.z - HITBOX_W/2,
                        targetPos.x + HITBOX_W/2, targetPos.y + HITBOX_H, targetPos.z + HITBOX_W/2,
                        1f, 1f, 0f, 0.8f);
            }
        }
    }

    private void renderSubTickSamples(VertexConsumer consumer, Matrix4f mat, Vec3d cam) {
        if (currentTick >= session.records.size()) return;
        PlayerRecord rec = session.records.get(currentTick);
        if (rec.subTickAimSamples == null || rec.subTickAimSamples.size() < 2) return;

        // Convert each sub-tick yaw/pitch to a direction point 3 blocks ahead
        Vec3d origin = new Vec3d(rec.posX, rec.posY + 1.62, rec.posZ);
        Vec3d prevPoint = null;

        for (float[] sample : rec.subTickAimSamples) {
            float yawRad   = (float) Math.toRadians(sample[0]);
            float pitchRad = (float) Math.toRadians(sample[1]);
            double dx = -Math.sin(yawRad) * Math.cos(pitchRad);
            double dy = -Math.sin(pitchRad);
            double dz =  Math.cos(yawRad) * Math.cos(pitchRad);
            Vec3d point = origin.add(dx * 3, dy * 3, dz * 3);

            if (prevPoint != null) {
                Vec3d a = prevPoint.subtract(cam);
                Vec3d b = point.subtract(cam);
                // Magenta for sub-tick samples
                addLine(consumer, mat,
                        (float)a.x, (float)a.y, (float)a.z,
                        (float)b.x, (float)b.y, (float)b.z,
                        1f, 0f, 1f, 0.9f);
            }
            prevPoint = point;
        }
    }

    // --- Pre-computation ---

    private void rebuildTrajectory() {
        trajectoryPoints.clear();
        for (PlayerRecord rec : session.records) {
            // Trajectory point = eye position + look direction * 4 blocks
            float yawRad   = (float) Math.toRadians(rec.yaw);
            float pitchRad = (float) Math.toRadians(rec.pitch);
            double dx = -Math.sin(yawRad) * Math.cos(pitchRad);
            double dy = -Math.sin(pitchRad);
            double dz =  Math.cos(yawRad) * Math.cos(pitchRad);
            double eyeY = rec.posY + 1.62;
            trajectoryPoints.add(new Vec3d(rec.posX + dx * 4, eyeY + dy * 4, rec.posZ + dz * 4));
        }
    }

    /**
     * Detect red zones: windows of ticks where aim angle to target is
     * suspiciously consistent (variance below threshold).
     * Window size: 10 ticks.
     */
    private void detectRedZones() {
        redZoneRanges.clear();
        List<PlayerRecord> records = session.records;
        int window = 10;
        float threshold = 0.08f; // degrees, matches VarianceEngine.AIM_VARIANCE_THRESHOLD

        List<Float> angles = new ArrayList<>();
        List<Integer> tickIndices = new ArrayList<>();
        for (int i = 0; i < records.size(); i++) {
            PlayerRecord r = records.get(i);
            if (r.hasCombatEvent) {
                angles.add(Math.abs(r.angleToTarget));
                tickIndices.add(i);
            }
        }

        for (int i = 0; i <= angles.size() - window; i++) {
            List<Float> slice = angles.subList(i, i + window);
            if (variance(slice) < threshold) {
                int startIdx = tickIndices.get(i);
                int endIdx   = tickIndices.get(i + window - 1);
                redZoneRanges.add(new int[]{startIdx, endIdx});
            }
        }
    }

    private float variance(List<Float> vals) {
        double mean = vals.stream().mapToDouble(Float::floatValue).average().orElse(0);
        double sumSq = vals.stream().mapToDouble(v -> (v - mean) * (v - mean)).sum();
        return (float)(sumSq / vals.size());
    }

    // Target position is estimated from raycast direction + reach distance at hit moment
    private Vec3d estimateTargetPos(PlayerRecord rec) {
        float yawRad   = (float) Math.toRadians(rec.yaw);
        float pitchRad = (float) Math.toRadians(rec.pitch);
        double dx = -Math.sin(yawRad) * Math.cos(pitchRad);
        double dy = -Math.sin(pitchRad);
        double dz =  Math.cos(yawRad) * Math.cos(pitchRad);
        double eyeY = rec.posY + 1.62;
        return new Vec3d(
            rec.posX + dx * rec.reachDistance,
            eyeY     + dy * rec.reachDistance - HITBOX_H / 2,
            rec.posZ + dz * rec.reachDistance
        );
    }

    // --- Wire box renderer ---

    private void renderBox(VertexConsumer consumer, Matrix4f mat, Vec3d cam,
                           double x1, double y1, double z1,
                           double x2, double y2, double z2,
                           float r, float g, float b, float a) {
        float ax = (float)(x1 - cam.x), ay = (float)(y1 - cam.y), az = (float)(z1 - cam.z);
        float bx = (float)(x2 - cam.x), by = (float)(y2 - cam.y), bz = (float)(z2 - cam.z);

        // Bottom face
        addLine(consumer, mat, ax, ay, az, bx, ay, az, r, g, b, a);
        addLine(consumer, mat, bx, ay, az, bx, ay, bz, r, g, b, a);
        addLine(consumer, mat, bx, ay, bz, ax, ay, bz, r, g, b, a);
        addLine(consumer, mat, ax, ay, bz, ax, ay, az, r, g, b, a);
        // Top face
        addLine(consumer, mat, ax, by, az, bx, by, az, r, g, b, a);
        addLine(consumer, mat, bx, by, az, bx, by, bz, r, g, b, a);
        addLine(consumer, mat, bx, by, bz, ax, by, bz, r, g, b, a);
        addLine(consumer, mat, ax, by, bz, ax, by, az, r, g, b, a);
        // Verticals
        addLine(consumer, mat, ax, ay, az, ax, by, az, r, g, b, a);
        addLine(consumer, mat, bx, ay, az, bx, by, az, r, g, b, a);
        addLine(consumer, mat, bx, ay, bz, bx, by, bz, r, g, b, a);
        addLine(consumer, mat, ax, ay, bz, ax, by, bz, r, g, b, a);
    }

    private void addLine(VertexConsumer consumer, Matrix4f mat,
                         float x1, float y1, float z1,
                         float x2, float y2, float z2,
                         float r, float g, float b, float a) {
        float nx = x2 - x1, ny = y2 - y1, nz = z2 - z1;
        float len = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
        if (len == 0) return;
        nx /= len; ny /= len; nz /= len;

        consumer.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(nx, ny, nz);
        consumer.vertex(mat, x2, y2, z2).color(r, g, b, a).normal(nx, ny, nz);
    }
}
