package dev.allicite.exileac.network;

import dev.allicite.exileac.client.CameraController;
import dev.allicite.exileac.client.ExileFTWClient;
import dev.allicite.exileac.client.ReviewUI;
import dev.allicite.exileac.server.data.ExileFile;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ClientPacketHandler {

    public static void register() {
        // Session data
        ClientPlayNetworking.registerGlobalReceiver(PacketChannel.SessionDataPayload.ID, (payload, context) -> {
            try {
                ExileFile file = ExileFile.deserialize(payload.exileBytes());
                MinecraftClient.getInstance().execute(() -> {
                    if (ExileFTWClient.reviewUI != null)
                        ExileFTWClient.reviewUI.onSessionDataReceived(file);
                });
            } catch (IOException e) {
                System.err.println("[ExileFTW] Failed to deserialize session: " + e.getMessage());
            }
        });

        // Suspicion map
        ClientPlayNetworking.registerGlobalReceiver(PacketChannel.SuspicionMapPayload.ID, (payload, context) -> {
            List<ReviewUI.PlayerEntry> entries = new ArrayList<>();
            for (PacketChannel.SuspicionEntry e : payload.entries())
                entries.add(new ReviewUI.PlayerEntry(e.uuid(), e.name(), e.level()));
            MinecraftClient.getInstance().execute(() -> {
                if (ExileFTWClient.reviewUI != null)
                    ExileFTWClient.reviewUI.onSuspicionMapReceived(entries);
            });
        });

        // Live tick data
        ClientPlayNetworking.registerGlobalReceiver(PacketChannel.LiveTickPayload.ID, (payload, context) -> {
            MinecraftClient.getInstance().execute(() -> {
                if (ExileFTWClient.reviewUI != null)
                    ExileFTWClient.reviewUI.onLiveTickReceived(payload);
            });
        });

        // Camera POV — update CameraController with target's eye position
        ClientPlayNetworking.registerGlobalReceiver(PacketChannel.CameraPovPayload.ID, (payload, context) -> {
            MinecraftClient.getInstance().execute(() -> {
                if (CameraController.isActive()) {
                    CameraController.updateTarget(
                        payload.x(), payload.y(), payload.z(),
                        payload.yaw(), payload.pitch()
                    );
                }
            });
        });

        // Export received
        ClientPlayNetworking.registerGlobalReceiver(PacketChannel.ExileExportPayload.ID, (payload, context) -> {
            MinecraftClient.getInstance().execute(() -> {
                if (ExileFTWClient.reviewUI != null)
                    ExileFTWClient.reviewUI.onExileExportReceived(
                            payload.exileBytes(), payload.playerUUID());
            });
        });
    }

    public static void requestSessions(UUID uuid)  { ClientPlayNetworking.send(new PacketChannel.RequestSessionsPayload(uuid)); }
    public static void requestLive(UUID uuid)      { ClientPlayNetworking.send(new PacketChannel.RequestLivePayload(uuid)); }
    public static void requestSuspicionMap()       { ClientPlayNetworking.send(new PacketChannel.RequestSuspicionPayload()); }
    public static void startSpectating(UUID uuid)  {
        CameraController.activate();
        ClientPlayNetworking.send(new PacketChannel.SpectateStartPayload(uuid));
    }
    public static void stopSpectating() {
        CameraController.deactivate();
        ClientPlayNetworking.send(new PacketChannel.SpectateStopPayload());
    }
    public static void requestExport(UUID uuid)    { ClientPlayNetworking.send(new PacketChannel.ExportRequestPayload(uuid)); }
}
