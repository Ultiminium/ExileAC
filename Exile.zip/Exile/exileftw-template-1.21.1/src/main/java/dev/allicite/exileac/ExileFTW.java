package dev.allicite.exileac;

import dev.allicite.exileac.server.*;
import dev.allicite.exileac.server.data.ExileDataLayer;
import dev.allicite.exileac.network.PacketChannel;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExileFTW implements ModInitializer {

    public static final String MOD_ID = "exileftw";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static TickRecorder      tickRecorder;
    public static SuspicionTracker  suspicionTracker;
    public static BotManager        botManager;
    public static ExileDataLayer    dataLayer;
    public static SpectateHandler   spectateHandler;
    public static WarningLog        warningLog;
    public static VarianceLog       varianceLog;
    public static VelocityDetector  velocityDetector;
    public static BacktrackDetector backtrackDetector;

    @Override
    public void onInitialize() {
        LOGGER.info("[ExileFTW] Initializing.");

        dataLayer         = new ExileDataLayer();
        tickRecorder      = new TickRecorder();
        suspicionTracker  = new SuspicionTracker();
        botManager        = new BotManager();
        spectateHandler   = new SpectateHandler();
        warningLog        = new WarningLog();
        varianceLog       = new VarianceLog();
        velocityDetector  = new VelocityDetector();
        backtrackDetector = new BacktrackDetector();

        // Register combat hook via Fabric event — no mixin needed
        CombatHook.register();

        PacketChannel.registerServerReceivers();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickRecorder.onServerTick(server);
            botManager.onServerTick(server);
            suspicionTracker.onServerTick(server);
            spectateHandler.onServerTick(server);
            server.getPlayerManager().getPlayerList()
                .forEach(p -> velocityDetector.checkVelocity(p));
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            var player = handler.getPlayer();
            suspicionTracker.trackPlayer(player.getUuid(), player.getName().getString());
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            var player = handler.getPlayer();
            spectateHandler.onStaffDisconnect(player.getUuid());
            velocityDetector.clearPlayer(player.getUuid());
            backtrackDetector.clearPlayer(player.getUuid());
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            LOGGER.info("[ExileFTW] Flushing data...");
            dataLayer.flushAll();
        });

        LOGGER.info("[ExileFTW] Ready.");
    }
}
