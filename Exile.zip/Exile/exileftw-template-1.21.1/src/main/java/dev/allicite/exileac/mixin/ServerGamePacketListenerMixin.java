package dev.allicite.exileac.mixin;

import dev.allicite.exileac.ExileFTW;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public class ServerGamePacketListenerMixin {

    @Shadow
    public ServerPlayerEntity player;

    @Inject(method = "onPlayerMove", at = @At("HEAD"))
    private void exileftw_onMovementPacket(PlayerMoveC2SPacket packet, CallbackInfo ci) {
        if (!packet.changesLook()) return;

        float yaw   = packet.getYaw(player.getYaw());
        float pitch = packet.getPitch(player.getPitch());

        ExileFTW.tickRecorder.onRawMovementPacket(
            player.getUuid(), yaw, pitch,
            player.server.getTicks()
        );
    }
}
