package dev.allicite.exileac.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.entity.LivingEntity;

/**
 * Placeholder — damage is hooked via EntityDamageEvent in TickRecorder.
 * No mixin injection needed.
 */
@Mixin(LivingEntity.class)
public class ServerLivingEntityMixin {
}
