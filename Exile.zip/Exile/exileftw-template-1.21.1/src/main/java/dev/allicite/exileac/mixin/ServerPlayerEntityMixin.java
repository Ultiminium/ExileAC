package dev.allicite.exileac.mixin;

import dev.allicite.exileac.server.CombatHook;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayerEntity.class)
public class ServerPlayerEntityMixin {

    /**
     * Inject after attack() to capture the combat event.
     * We inject at RETURN so we know if the hit was processed (not cancelled by other logic).
     */
    @Inject(method = "attack", at = @At("RETURN"))
    private void exileftw_onAttack(Entity target, CallbackInfo ci) {
        ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;
        // hitRegistered = true if the target's health changed this tick (approximated by damage taken flag)
        // More precise tracking requires a DamageSource mixin, added in Phase 2
        boolean hitRegistered = !target.isInvulnerable();
        //CombatHook.onAttack(self, target, hitRegistered, self.getServer().getTicks());
    }
}
