package dev.allicite.exileac.network;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.server.ExileExporter;
import dev.allicite.exileac.server.data.ExileFile;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PacketChannel {

    public static final Identifier REQUEST_SESSIONS_ID  = Identifier.of("exileftw", "request_sessions");
    public static final Identifier REQUEST_LIVE_ID      = Identifier.of("exileftw", "request_live");
    public static final Identifier REQUEST_SUSPICION_ID = Identifier.of("exileftw", "request_suspicion");
    public static final Identifier SESSION_DATA_ID      = Identifier.of("exileftw", "session_data");
    public static final Identifier SUSPICION_MAP_ID     = Identifier.of("exileftw", "suspicion_map");
    public static final Identifier SPECTATE_START_ID    = Identifier.of("exileftw", "spectate_start");
    public static final Identifier SPECTATE_STOP_ID     = Identifier.of("exileftw", "spectate_stop");
    public static final Identifier LIVE_TICK_ID         = Identifier.of("exileftw", "live_tick");
    public static final Identifier EXPORT_REQUEST_ID    = Identifier.of("exileftw", "export_request");
    public static final Identifier EXILE_EXPORT_ID      = Identifier.of("exileftw", "exile_export");
    public static final Identifier CAMERA_POV_ID        = Identifier.of("exileftw", "camera_pov");

    // --- C2S ---

    public record RequestSessionsPayload(UUID targetUUID) implements CustomPayload {
        public static final CustomPayload.Id<RequestSessionsPayload> ID = new CustomPayload.Id<>(REQUEST_SESSIONS_ID);
        public static final PacketCodec<PacketByteBuf, RequestSessionsPayload> CODEC = PacketCodec.of(
            (v, buf) -> writeUUID(buf, v.targetUUID), buf -> new RequestSessionsPayload(readUUID(buf)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record RequestLivePayload(UUID targetUUID) implements CustomPayload {
        public static final CustomPayload.Id<RequestLivePayload> ID = new CustomPayload.Id<>(REQUEST_LIVE_ID);
        public static final PacketCodec<PacketByteBuf, RequestLivePayload> CODEC = PacketCodec.of(
            (v, buf) -> writeUUID(buf, v.targetUUID), buf -> new RequestLivePayload(readUUID(buf)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record RequestSuspicionPayload() implements CustomPayload {
        public static final CustomPayload.Id<RequestSuspicionPayload> ID = new CustomPayload.Id<>(REQUEST_SUSPICION_ID);
        public static final PacketCodec<PacketByteBuf, RequestSuspicionPayload> CODEC = PacketCodec.of(
            (v, buf) -> {}, buf -> new RequestSuspicionPayload());
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record SpectateStartPayload(UUID targetUUID) implements CustomPayload {
        public static final CustomPayload.Id<SpectateStartPayload> ID = new CustomPayload.Id<>(SPECTATE_START_ID);
        public static final PacketCodec<PacketByteBuf, SpectateStartPayload> CODEC = PacketCodec.of(
            (v, buf) -> writeUUID(buf, v.targetUUID), buf -> new SpectateStartPayload(readUUID(buf)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record SpectateStopPayload() implements CustomPayload {
        public static final CustomPayload.Id<SpectateStopPayload> ID = new CustomPayload.Id<>(SPECTATE_STOP_ID);
        public static final PacketCodec<PacketByteBuf, SpectateStopPayload> CODEC = PacketCodec.of(
            (v, buf) -> {}, buf -> new SpectateStopPayload());
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record ExportRequestPayload(UUID targetUUID) implements CustomPayload {
        public static final CustomPayload.Id<ExportRequestPayload> ID = new CustomPayload.Id<>(EXPORT_REQUEST_ID);
        public static final PacketCodec<PacketByteBuf, ExportRequestPayload> CODEC = PacketCodec.of(
            (v, buf) -> writeUUID(buf, v.targetUUID), buf -> new ExportRequestPayload(readUUID(buf)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // --- S2C ---

    public record SessionDataPayload(byte[] exileBytes) implements CustomPayload {
        public static final CustomPayload.Id<SessionDataPayload> ID = new CustomPayload.Id<>(SESSION_DATA_ID);
        public static final PacketCodec<PacketByteBuf, SessionDataPayload> CODEC = PacketCodec.of(
            (v, buf) -> { buf.writeInt(v.exileBytes.length); buf.writeBytes(v.exileBytes); },
            buf -> { int len = buf.readInt(); byte[] b = new byte[len]; buf.readBytes(b); return new SessionDataPayload(b); });
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record SuspicionEntry(UUID uuid, String name, int level) {}

    public record SuspicionMapPayload(List<SuspicionEntry> entries) implements CustomPayload {
        public static final CustomPayload.Id<SuspicionMapPayload> ID = new CustomPayload.Id<>(SUSPICION_MAP_ID);
        public static final PacketCodec<PacketByteBuf, SuspicionMapPayload> CODEC = PacketCodec.of(
            (v, buf) -> {
                buf.writeInt(v.entries.size());
                for (SuspicionEntry e : v.entries) {
                    writeUUID(buf, e.uuid()); buf.writeString(e.name()); buf.writeInt(e.level());
                }
            },
            buf -> {
                int count = buf.readInt();
                List<SuspicionEntry> entries = new ArrayList<>();
                for (int i = 0; i < count; i++)
                    entries.add(new SuspicionEntry(readUUID(buf), buf.readString(), buf.readInt()));
                return new SuspicionMapPayload(entries);
            });
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record LiveTickPayload(
        UUID targetUUID,
        double posX, double posY, double posZ,
        float yaw, float pitch,
        double velX, double velY, double velZ,
        float health, float maxHealth,
        float reach, float angleToTarget,
        boolean hasCombat, int suspicionLevel
    ) implements CustomPayload {
        public static final CustomPayload.Id<LiveTickPayload> ID = new CustomPayload.Id<>(LIVE_TICK_ID);
        public static final PacketCodec<PacketByteBuf, LiveTickPayload> CODEC = PacketCodec.of(
            (v, buf) -> {
                writeUUID(buf, v.targetUUID);
                buf.writeDouble(v.posX); buf.writeDouble(v.posY); buf.writeDouble(v.posZ);
                buf.writeFloat(v.yaw);   buf.writeFloat(v.pitch);
                buf.writeDouble(v.velX); buf.writeDouble(v.velY); buf.writeDouble(v.velZ);
                buf.writeFloat(v.health); buf.writeFloat(v.maxHealth);
                buf.writeFloat(v.reach); buf.writeFloat(v.angleToTarget);
                buf.writeBoolean(v.hasCombat); buf.writeInt(v.suspicionLevel);
            },
            buf -> new LiveTickPayload(
                readUUID(buf),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readFloat(), buf.readFloat(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readFloat(), buf.readFloat(),
                buf.readFloat(), buf.readFloat(),
                buf.readBoolean(), buf.readInt()
            ));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record ExileExportPayload(UUID playerUUID, byte[] exileBytes) implements CustomPayload {
        public static final CustomPayload.Id<ExileExportPayload> ID = new CustomPayload.Id<>(EXILE_EXPORT_ID);
        public static final PacketCodec<PacketByteBuf, ExileExportPayload> CODEC = PacketCodec.of(
            (v, buf) -> { writeUUID(buf, v.playerUUID); buf.writeInt(v.exileBytes.length); buf.writeBytes(v.exileBytes); },
            buf -> { UUID u = readUUID(buf); int len = buf.readInt(); byte[] b = new byte[len]; buf.readBytes(b); return new ExileExportPayload(u, b); });
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /** S2C: Sent every tick while spectating — tells client where to position its camera. */
    public record CameraPovPayload(
        double x, double y, double z,
        float yaw, float pitch
    ) implements CustomPayload {
        public static final CustomPayload.Id<CameraPovPayload> ID = new CustomPayload.Id<>(CAMERA_POV_ID);
        public static final PacketCodec<PacketByteBuf, CameraPovPayload> CODEC = PacketCodec.of(
            (v, buf) -> {
                buf.writeDouble(v.x); buf.writeDouble(v.y); buf.writeDouble(v.z);
                buf.writeFloat(v.yaw); buf.writeFloat(v.pitch);
            },
            buf -> new CameraPovPayload(
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readFloat(), buf.readFloat()
            ));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // --- Registration ---

    public static void registerServerReceivers() {
        PayloadTypeRegistry.playC2S().register(RequestSessionsPayload.ID, RequestSessionsPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestLivePayload.ID, RequestLivePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestSuspicionPayload.ID, RequestSuspicionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SpectateStartPayload.ID, SpectateStartPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SpectateStopPayload.ID, SpectateStopPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ExportRequestPayload.ID, ExportRequestPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SessionDataPayload.ID, SessionDataPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SuspicionMapPayload.ID, SuspicionMapPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(LiveTickPayload.ID, LiveTickPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ExileExportPayload.ID, ExileExportPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CameraPovPayload.ID, CameraPovPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(RequestSessionsPayload.ID, (payload, context) -> {
            if (!isStaff(context.player())) return;
            UUID target = payload.targetUUID();
            context.server().execute(() -> {
                List<ExileFile> sessions = ExileFTW.dataLayer.loadSessions(target);
                for (ExileFile s : sessions) {
                    try { ServerPlayNetworking.send(context.player(), new SessionDataPayload(s.serialize())); }
                    catch (IOException e) { ExileFTW.LOGGER.error("[ExileFTW] Serialize failed", e); }
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(RequestLivePayload.ID, (payload, context) -> {
            if (!isStaff(context.player())) return;
            context.server().execute(() -> {
                ExileFile live = ExileFTW.dataLayer.getLiveSession(payload.targetUUID());
                if (live != null) {
                    try { ServerPlayNetworking.send(context.player(), new SessionDataPayload(live.serialize())); }
                    catch (IOException e) { ExileFTW.LOGGER.error("[ExileFTW] Live serialize failed", e); }
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(RequestSuspicionPayload.ID, (payload, context) -> {
            if (!isStaff(context.player())) return;
            context.server().execute(() -> ExileFTW.suspicionTracker.pushSuspicionMapToStaff(context.server()));
        });

        ServerPlayNetworking.registerGlobalReceiver(SpectateStartPayload.ID, (payload, context) -> {
            if (!isStaff(context.player())) return;
            context.server().execute(() ->
                ExileFTW.spectateHandler.startSpectating(context.player().getUuid(), payload.targetUUID()));
        });

        ServerPlayNetworking.registerGlobalReceiver(SpectateStopPayload.ID, (payload, context) -> {
            if (!isStaff(context.player())) return;
            context.server().execute(() ->
                ExileFTW.spectateHandler.stopSpectating(context.player().getUuid()));
        });

        ServerPlayNetworking.registerGlobalReceiver(ExportRequestPayload.ID, (payload, context) -> {
            if (!isStaff(context.player())) return;
            context.server().execute(() ->
                ExileExporter.exportAndSend(payload.targetUUID(), context.player(), context.server()));
        });

        ExileFTW.LOGGER.info("[ExileFTW] Packet channel registered.");
    }

    private static boolean isStaff(ServerPlayerEntity player) {
        return player.server.getPlayerManager().isOperator(player.getGameProfile());
    }

    private static void writeUUID(PacketByteBuf buf, UUID uuid) {
        buf.writeLong(uuid.getMostSignificantBits());
        buf.writeLong(uuid.getLeastSignificantBits());
    }
    private static UUID readUUID(PacketByteBuf buf) {
        return new UUID(buf.readLong(), buf.readLong());
    }
}
