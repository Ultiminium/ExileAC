package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Detects backtrack (lag compensation abuse).
 *
 * Backtrack works by making the client delay sending position updates,
 * then attacking a target at a position they were at N ticks ago.
 * From the server's perspective, the hit is registered at the target's
 * CURRENT position — but the angle/distance from attacker don't match
 * current target position, they match a historical one.
 *
 * Detection:
 * We maintain a position history buffer (last 20 ticks) for each player.
 * When an attack is registered, we check:
 *   1. Does the attacker's look direction match the target's CURRENT position?
 *   2. If not, does it match any position in the history buffer?
 *   3. If it matches a historical position better than the current, flag it.
 */
public class BacktrackDetector {

    private static final int HISTORY_SIZE        = 20; // ticks of position history
    private static final float ANGLE_MATCH_THRESHOLD = 3.0f; // degrees — within this = "matches"
    private static final int MIN_BACKTRACK_TICKS  = 3;  // minimum ticks back to flag

    // UUID -> circular buffer of recent positions
    private final Map<UUID, Deque<PositionSnapshot>> positionHistory = new ConcurrentHashMap<>();

    public record PositionSnapshot(double x, double y, double z, int tick) {}

    /**
     * Record a player's position every tick.
     */
    public void recordPosition(ServerPlayerEntity player, int tick) {
        UUID uuid = player.getUuid();
        Deque<PositionSnapshot> history = positionHistory.computeIfAbsent(
                uuid, k -> new ArrayDeque<>());

        history.addLast(new PositionSnapshot(
                player.getX(), player.getY(), player.getZ(), tick));

        if (history.size() > HISTORY_SIZE) history.removeFirst();
    }

    /**
     * Called when player A attacks player B.
     * Checks if the hit angle matches a historical position rather than current.
     */
    public void checkAttack(ServerPlayerEntity attacker, ServerPlayerEntity target,
                            float registeredAngle, int currentTick) {
        UUID targetUUID = target.getUuid();
        Deque<PositionSnapshot> history = positionHistory.get(targetUUID);
        if (history == null || history.size() < MIN_BACKTRACK_TICKS + 1) return;

        Vec3d eyePos = attacker.getEyePos();
        float yawRad   = (float) Math.toRadians(attacker.getYaw());
        float pitchRad = (float) Math.toRadians(attacker.getPitch());
        Vec3d lookDir  = new Vec3d(
            -Math.sin(yawRad) * Math.cos(pitchRad),
            -Math.sin(pitchRad),
             Math.cos(yawRad) * Math.cos(pitchRad)
        ).normalize();

        // Angle to target's CURRENT position
        Vec3d currentCenter = target.getBoundingBox().getCenter();
        float currentAngle  = angleBetween(lookDir, eyePos, currentCenter);

        // If current angle matches well, not backtrack
        if (currentAngle < ANGLE_MATCH_THRESHOLD) return;

        // Check historical positions
        List<PositionSnapshot> snapshots = new ArrayList<>(history);
        for (int i = snapshots.size() - 2; i >= 0; i--) {
            PositionSnapshot snap = snapshots.get(i);
            int ticksBack = currentTick - snap.tick();
            if (ticksBack < MIN_BACKTRACK_TICKS) continue;

            // Approximate hitbox center at historical position
            Vec3d historicalCenter = new Vec3d(snap.x(), snap.y() + 0.9, snap.z());
            float historicalAngle  = angleBetween(lookDir, eyePos, historicalCenter);

            if (historicalAngle < ANGLE_MATCH_THRESHOLD && historicalAngle < currentAngle - 5f) {
                // Hit matches a historical position better than current
                ExileFTW.LOGGER.warn(
                    "[ExileFTW] BACKTRACK FLAG: {} hit {} at historical pos ({} ticks back) " +
                    "current_angle={}° historical_angle={}°",
                    attacker.getName().getString(), target.getName().getString(),
                    ticksBack,
                    String.format("%.2f", currentAngle),
                    String.format("%.2f", historicalAngle)
                );
                ExileFTW.warningLog.log(attacker.getUuid(), String.format(
                    "BACKTRACK: hit matched position %d ticks ago (current=%.2f° hist=%.2f°)",
                    ticksBack, currentAngle, historicalAngle
                ));

                // Boost suspicion
                int current = ExileFTW.suspicionTracker.getLevel(attacker.getUuid());
                ExileFTW.suspicionTracker.setLevel(attacker.getUuid(), Math.min(10, current + 2));
                break;
            }
        }
    }

    private float angleBetween(Vec3d lookDir, Vec3d eyePos, Vec3d targetPos) {
        Vec3d toTarget = targetPos.subtract(eyePos).normalize();
        double dot = Math.max(-1.0, Math.min(1.0, lookDir.dotProduct(toTarget)));
        return (float) Math.toDegrees(Math.acos(dot));
    }

    public void clearPlayer(UUID uuid) {
        positionHistory.remove(uuid);
    }
}
