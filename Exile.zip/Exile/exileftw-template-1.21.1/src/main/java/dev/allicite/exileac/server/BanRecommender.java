package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.server.data.ExileFile;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Generates a human-readable ban recommendation from variance data and warning logs.
 * Used for ban appeals and staff review.
 */
public class BanRecommender {

    public record BanReport(
        String playerName,
        UUID playerUUID,
        int suspicionLevel,
        String recommendation,
        List<String> evidence,
        String rawSummary
    ) {
        public String formatForChat() {
            StringBuilder sb = new StringBuilder();
            sb.append("§c§l=== ExileFTW Ban Report ===\n");
            sb.append("§7Player: §f").append(playerName).append("\n");
            sb.append("§7UUID:   §8").append(playerUUID).append("\n");
            sb.append("§7Level:  ").append(suspicionColor(suspicionLevel))
              .append(suspicionLevel).append("/10\n");
            sb.append("§7Verdict: §f").append(recommendation).append("\n");
            sb.append("§7Evidence:\n");
            for (String e : evidence) {
                sb.append("  §8• §7").append(e).append("\n");
            }
            return sb.toString();
        }

        public String formatForExport() {
            StringBuilder sb = new StringBuilder();
            sb.append("ExileFTW Ban Report\n");
            sb.append("===================\n");
            sb.append("Player: ").append(playerName).append("\n");
            sb.append("UUID:   ").append(playerUUID).append("\n");
            sb.append("Suspicion Level: ").append(suspicionLevel).append("/10\n");
            sb.append("Verdict: ").append(recommendation).append("\n\n");
            sb.append("Evidence:\n");
            for (String e : evidence) sb.append("  - ").append(e).append("\n");
            sb.append("\nRaw Analysis:\n").append(rawSummary).append("\n\n");
            sb.append("Warning Log:\n");
            ExileFTW.warningLog.getLogsFor(playerUUID).forEach(l ->
                sb.append("  ").append(l).append("\n"));
            return sb.toString();
        }

        private static String suspicionColor(int level) {
            if (level >= 9) return "§c";
            if (level >= 7) return "§6";
            if (level >= 5) return "§e";
            return "§a";
        }
    }

    public static BanReport generate(UUID playerUUID, String playerName) {
        int suspicionLevel = ExileFTW.suspicionTracker.getLevel(playerUUID);
        VarianceEngine.AnalysisResult variance = ExileFTW.varianceLog.getLatest(playerUUID);
        List<String> warnings = ExileFTW.warningLog.getLogsFor(playerUUID);

        List<String> evidence = new ArrayList<>();
        String recommendation;
        String rawSummary = variance != null ? variance.summary() : "No analysis data available.";

        // Build evidence list from variance data
        if (variance != null) {
            // Reach evidence
            if (variance.averageReach > 3.2f) {
                evidence.add(String.format(
                    "Extended reach detected: avg=%.3fb, max=%.3fb (%d hits above vanilla max of 3.05b)",
                    variance.averageReach, variance.maxReach, variance.hitsAboveVanillaMax));
            }

            // Triggerbot evidence
            if (variance.triggerbotSampleCount > 0) {
                float ratio = (float) variance.triggerbotFastFires / variance.triggerbotSampleCount;
                if (ratio > 0.4f) {
                    evidence.add(String.format(
                        "Triggerbot pattern: %.0f%% of attacks fired within 1 tick of aim acquisition (avg delay=%.2f ticks)",
                        ratio * 100, variance.avgTriggerbotDelay));
                }
            }

            // Ping spoof evidence
            if (variance.packetJitterMs < 2.0f && variance.packetSampleCount > 20) {
                evidence.add(String.format(
                    "Packet timing anomaly: %.4fms jitter (below human threshold of 2ms) over %d samples",
                    variance.packetJitterMs, variance.packetSampleCount));
            }

            // Aim lock evidence
            if (variance.aimLockSequences >= 2) {
                evidence.add(String.format(
                    "Aim lock sequences: %d detected (variance=%.4f°)",
                    variance.aimLockSequences, variance.aimDeltaVariance));
            }

            // Zero-variance swap evidence
            if (variance.zeroVarianceSwaps >= 2) {
                evidence.add(String.format(
                    "Macro sprint-reset pattern: %d zero-variance sequences (variance=%.4f ticks)",
                    variance.zeroVarianceSwaps, variance.swapIntervalVariance));
            }
        }

        // Add warning log entries as evidence
        for (String warning : warnings) {
            if (warning.contains("BACKTRACK")) {
                evidence.add("Backtrack detected: " + warning.substring(warning.indexOf("BACKTRACK:")));
                break;
            }
        }
        for (String warning : warnings) {
            if (warning.contains("VELOCITY")) {
                evidence.add("Velocity manipulation detected: " + warning.substring(warning.indexOf("VELOCITY:")));
                break;
            }
        }

        // Generate recommendation
        if (suspicionLevel >= 9) {
            recommendation = "BAN RECOMMENDED — Multiple independent cheat signatures detected with high confidence.";
        } else if (suspicionLevel >= 7) {
            recommendation = "BAN LIKELY — Significant statistical anomalies detected. Manual review of .exile replay recommended.";
        } else if (suspicionLevel >= 5) {
            recommendation = "MONITOR — Suspicious patterns present but insufficient for confident ban. Continue data collection.";
        } else if (evidence.isEmpty()) {
            recommendation = "NO ACTION — Insufficient evidence. Suspicion level too low.";
        } else {
            recommendation = "WATCH — Minor anomalies detected. Not actionable alone.";
        }

        if (evidence.isEmpty()) {
            evidence.add("No specific cheat signatures isolated — suspicion from overall pattern analysis.");
        }

        return new BanReport(playerName, playerUUID, suspicionLevel,
                recommendation, evidence, rawSummary);
    }
}
