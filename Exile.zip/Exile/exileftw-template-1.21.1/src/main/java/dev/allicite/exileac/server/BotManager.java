package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Spawns and manages invisible honeypot entities for players at suspicion level 10.
 *
 * Design:
 * - 5 invisible ArmorStand entities per flagged player
 * - Hover 120 blocks above the player, anchored to their position each tick
 * - Randomly receive large downward velocity to simulate a falling player
 * - Exist server-side only — never sent to the flagged player's client
 *   (achieved by tracking which player to exclude from entity visibility)
 * - Not joined players — raw entities with no name, no packets to the suspect
 *
 * Detection logic:
 * - A cheater using reach/aimassist with packet-level target detection will
 *   register hits or aim corrections toward these entities
 * - Logged as high-confidence combat events against non-existent players
 */
public class BotManager {

    private static final int BOT_COUNT = 5;
    private static final double BOT_HEIGHT_OFFSET = 120.0;
    private static final double RANDOM_VELOCITY_CHANCE = 0.03; // 3% per tick per bot
    private static final double RANDOM_DOWNWARD_VELOCITY = -3.5;

    // Map of suspect UUID -> their honeypot entity UUIDs
    private final Map<UUID, List<UUID>> suspectBots = new HashMap<>();
    // Map of entity UUID -> the ArmorStandEntity reference
    private final Map<UUID, ArmorStandEntity> botEntities = new HashMap<>();

    private final Random rng = new Random();

    /** Spawn 5 honeypot bots above the suspect. */
    public void spawnBotsFor(UUID suspectUUID) {
        // Deferred to next tick when we have server context — called from onServerTick
        suspectBots.put(suspectUUID, new ArrayList<>());
    }

    /** Remove all bots for a player (on disconnect or suspicion drop). */
    public void removeBotsFor(UUID suspectUUID) {
        List<UUID> botUUIDs = suspectBots.remove(suspectUUID);
        if (botUUIDs == null) return;
        for (UUID botUUID : botUUIDs) {
            ArmorStandEntity bot = botEntities.remove(botUUID);
            if (bot != null) bot.discard();
        }
    }

    /** Called every server tick. Anchors bots to suspect positions and applies random velocity. */
    public void onServerTick(MinecraftServer server) {
        for (Map.Entry<UUID, List<UUID>> entry : suspectBots.entrySet()) {
            UUID suspectUUID = entry.getKey();
            List<UUID> botUUIDs = entry.getValue();

            ServerPlayerEntity suspect = server.getPlayerManager().getPlayer(suspectUUID);
            if (suspect == null) continue;

            ServerWorld world = (ServerWorld) suspect.getWorld();

            // Spawn bots if not yet spawned
            if (botUUIDs.isEmpty()) {
                spawnBotsInWorld(suspectUUID, suspect, world, botUUIDs);
            }

            // Anchor bots above suspect + apply random velocity
            Vec3d suspectPos = suspect.getPos();
            for (UUID botUUID : botUUIDs) {
                ArmorStandEntity bot = botEntities.get(botUUID);
                if (bot == null || bot.isRemoved()) continue;

                // Slight randomized offset so bots aren't stacked
                double offsetX = (rng.nextDouble() - 0.5) * 4.0;
                double offsetZ = (rng.nextDouble() - 0.5) * 4.0;

                // Re-anchor position each tick (not a teleport — setPosition is smooth)
                bot.setPosition(
                    suspectPos.x + offsetX,
                    suspectPos.y + BOT_HEIGHT_OFFSET,
                    suspectPos.z + offsetZ
                );

                // Random downward velocity spike
                if (rng.nextDouble() < RANDOM_VELOCITY_CHANCE) {
                    bot.setVelocity(
                        (rng.nextDouble() - 0.5) * 0.5,
                        RANDOM_DOWNWARD_VELOCITY,
                        (rng.nextDouble() - 0.5) * 0.5
                    );
                }

                // Check if any player hits or aims at this bot — log as honeypot trigger
                checkHoneypotTrigger(bot, world, suspectUUID);
            }
        }
    }

    private void spawnBotsInWorld(UUID suspectUUID, ServerPlayerEntity suspect,
                                   ServerWorld world, List<UUID> botUUIDs) {
        Vec3d pos = suspect.getPos();
        for (int i = 0; i < BOT_COUNT; i++) {
            ArmorStandEntity bot = new ArmorStandEntity(EntityType.ARMOR_STAND, world);
            bot.setPosition(pos.x, pos.y + BOT_HEIGHT_OFFSET, pos.z);
            bot.setInvisible(true);
            bot.setInvulnerable(true);
            bot.setNoGravity(false); // gravity enabled so velocity works naturally
            bot.setSilent(true);
            bot.setCustomNameVisible(false);

            world.spawnEntity(bot);
            botUUIDs.add(bot.getUuid());
            botEntities.put(bot.getUuid(), bot);

            ExileFTW.LOGGER.debug("[ExileFTW] Spawned honeypot bot {} for suspect {}",
                    bot.getUuid(), suspectUUID);
        }
    }

    /**
     * If any player (other than the suspect) attacks or gets suspiciously close
     * to a honeypot bot, log it. This catches reach cheats targeting server-side entities.
     */
    private void checkHoneypotTrigger(ArmorStandEntity bot, ServerWorld world, UUID suspectUUID) {
        // Check all players within 10 blocks of the bot
        world.getPlayers().forEach(player -> {
            if (player.getUuid().equals(suspectUUID)) return; // the suspect can't see it anyway
            double dist = player.getPos().distanceTo(bot.getPos());
            if (dist < 10.0) {
                ExileFTW.LOGGER.warn("[ExileFTW] HONEYPOT TRIGGER: Player {} within {}b of honeypot for suspect {}",
                        player.getName().getString(), String.format("%.2f", dist), suspectUUID);
            }
        });
    }

    public boolean hasBots(UUID suspectUUID) {
        return suspectBots.containsKey(suspectUUID);
    }
}
