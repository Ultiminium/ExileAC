package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.server.data.PlayerRecord;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

/**
 * Hooks combat via Fabric's ServerLivingEntityEvents.AFTER_DAMAGE.
 * This fires AFTER damage is fully processed — no interference with
 * vanilla damage, knockback, or invulnerability frames whatsoever.
 */
public class CombatHook {

    public static void register() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register(
            (entity, source, baseDamageTaken, damageTaken, blocked) -> {
                // Only care about player attacks
                if (!(source.getAttacker() instanceof ServerPlayerEntity attacker)) return;
                // Skip if no damage actually landed
                if (damageTaken <= 0) return;

                onConfirmedHit(attacker, entity, attacker.getServer().getTicks());
            }
        );
    }

    private static void onConfirmedHit(ServerPlayerEntity attacker, LivingEntity target,
                                       int currentTick) {
        UUID attackerUUID = attacker.getUuid();

        Vec3d eyePos      = attacker.getEyePos();
        Vec3d targetCenter = target.getBoundingBox().getCenter();
        float reach = (float) eyePos.distanceTo(targetCenter);

        Vec3d toTarget = targetCenter.subtract(eyePos).normalize();

        float yawRad   = (float) Math.toRadians(attacker.getYaw());
        float pitchRad = (float) Math.toRadians(attacker.getPitch());
        Vec3d lookDir  = new Vec3d(
            -Math.sin(yawRad) * Math.cos(pitchRad),
            -Math.sin(pitchRad),
             Math.cos(yawRad) * Math.cos(pitchRad)
        ).normalize();

        double dot = Math.max(-1.0, Math.min(1.0, lookDir.dotProduct(toTarget)));
        float angleDelta = (float) Math.toDegrees(Math.acos(dot));

        float yawToTarget   = (float) Math.toDegrees(Math.atan2(-toTarget.x, toTarget.z));
        float pitchToTarget = (float) Math.toDegrees(Math.asin(-toTarget.y));
        float yawDelta      = normalizeAngle(attacker.getYaw() - yawToTarget);
        float pitchDelta    = attacker.getPitch() - pitchToTarget;

        if (reach > 3.6f) {
            ExileFTW.LOGGER.warn("[ExileFTW] REACH: {} hit {} at {}b",
                attacker.getName().getString(),
                target.getName().getString(),
                String.format("%.3f", reach));
            ExileFTW.warningLog.log(attackerUUID, String.format(
                "REACH HIT: %.3fb angle=%.2f° target=%s tick=%d",
                reach, angleDelta, target.getName().getString(), currentTick));
        }

        if (target instanceof ServerPlayerEntity targetPlayer) {
            ExileFTW.backtrackDetector.checkAttack(attacker, targetPlayer,
                    angleDelta, currentTick);
        }

        byte flags = 0;
        if (attacker.isSprinting())  flags |= 0x01;
        if (attacker.handSwinging)   flags |= 0x04;
        if (attacker.isSneaking())   flags |= 0x08;
        if (attacker.isOnGround())   flags |= 0x10;
        if (attacker.isBlocking())   flags |= 0x20;

        PlayerRecord record = new PlayerRecord.Builder()
                .player(attackerUUID)
                .tick(currentTick)
                .timestamp(System.currentTimeMillis())
                .pos(attacker.getX(), attacker.getY(), attacker.getZ())
                .orientation(attacker.getYaw(), attacker.getPitch())
                .velocity(attacker.getVelocity().x, attacker.getVelocity().y, attacker.getVelocity().z)
                .flags(flags)
                .combat(target.getUuid(), reach, yawDelta, pitchDelta, true)
                .sprintReset(false)
                .wTap(false)
                .build();

        ExileFTW.dataLayer.appendRecord(attackerUUID, record);
        ExileFTW.suspicionTracker.onCombatEvent(attackerUUID, reach, angleDelta, currentTick);
    }

    private static float normalizeAngle(float angle) {
        while (angle >  180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }
}
