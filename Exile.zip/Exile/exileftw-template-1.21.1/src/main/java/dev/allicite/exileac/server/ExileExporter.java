package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.network.PacketChannel;
import dev.allicite.exileac.server.data.ExileFile;
import dev.allicite.exileac.server.data.PlayerRecord;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.io.IOException;
import java.util.UUID;

/**
 * Packages a full player session into a .exile file and sends it to a requesting staff client.
 * Called when staff clicks [ Export .exile ] in the review UI.
 */
public class ExileExporter {

    public static void exportAndSend(UUID targetUUID, ServerPlayerEntity staffPlayer,
                                     MinecraftServer server) {
        ExileFile session = ExileFTW.dataLayer.getLiveSession(targetUUID);
        if (session == null) {
            // Try loading from disk
            var sessions = ExileFTW.dataLayer.loadSessions(targetUUID);
            if (sessions.isEmpty()) {
                ExileFTW.LOGGER.warn("[ExileFTW] No session data found for {} to export", targetUUID);
                return;
            }
            session = sessions.get(sessions.size() - 1); // most recent
        }

        // Populate combat log from tick records
        for (PlayerRecord rec : session.records) {
            if (rec.hasCombatEvent && rec.targetUUID != null) {
                session.combatLog.add(new ExileFile.CombatEntry(
                    rec.tick, rec.targetUUID, rec.reachDistance,
                    rec.angleToTarget, rec.pitchToTarget,
                    rec.hitRegistered, rec.stateFlags
                ));
            }
        }

        // Populate server logs from ExileFTW warning log
        session.serverLogs.addAll(ExileFTW.warningLog.getLogsFor(targetUUID));

        // Server name
        session.serverName = server.getServerMotd();
        if (session.serverName == null || session.serverName.isEmpty())
            session.serverName = "ExileFTW Server";
        // Strip formatting codes
        session.serverName = session.serverName.replaceAll("§.", "");
        if (session.serverName.length() > 14)
            session.serverName = session.serverName.substring(0, 14);

        // Attach variance snapshot if available
        var varianceResult = ExileFTW.varianceLog.getLatest(targetUUID);
        if (varianceResult != null) {
            ExileFile.VarianceSnapshot vs = new ExileFile.VarianceSnapshot();
            vs.swapIntervalVariance     = varianceResult.swapIntervalVariance;
            vs.swapSampleCount          = varianceResult.swapSampleCount;
            vs.zeroVarianceSwaps        = varianceResult.zeroVarianceSwaps;
            vs.aimDeltaVariance         = varianceResult.aimDeltaVariance;
            vs.aimSampleCount           = varianceResult.aimSampleCount;
            vs.aimLockSequences         = varianceResult.aimLockSequences;
            vs.reachVariance            = varianceResult.reachVariance;
            vs.averageReach             = varianceResult.averageReach;
            vs.reachSampleCount         = varianceResult.reachSampleCount;
            vs.cpsIntervalVarianceMs    = varianceResult.cpsIntervalVarianceMs;
            vs.cpsSampleCount           = varianceResult.cpsSampleCount;
            vs.zeroCpsVarianceSequences = varianceResult.zeroCpsVarianceSequences;
            session.variance = vs;
        }

        // Serialize and send
        try {
            byte[] bytes = session.serialize();
            ExileFTW.LOGGER.info("[ExileFTW] Exporting {}b .exile for {} to staff {}",
                    bytes.length, targetUUID, staffPlayer.getName().getString());
            ServerPlayNetworking.send(staffPlayer,
                    new PacketChannel.ExileExportPayload(targetUUID, bytes));
        } catch (IOException e) {
            ExileFTW.LOGGER.error("[ExileFTW] Failed to serialize export for {}", targetUUID, e);
        }
    }
}
