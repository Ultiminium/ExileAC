package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.network.PacketChannel;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles live spectate mode.
 * Pushes LiveTickPayload every tick to spectating staff.
 * Also pushes CameraPayload so the client can move its camera
 * to match the target's POV exactly.
 */
public class SpectateHandler {

    private final Map<UUID, UUID> activeSpectators = new ConcurrentHashMap<>();

    public void startSpectating(UUID staffUUID, UUID targetUUID) {
        activeSpectators.put(staffUUID, targetUUID);
        ExileFTW.LOGGER.info("[ExileFTW] {} started spectating {}", staffUUID, targetUUID);
    }

    public void stopSpectating(UUID staffUUID) {
        activeSpectators.remove(staffUUID);
        ExileFTW.LOGGER.info("[ExileFTW] {} stopped spectating", staffUUID);
    }

    public boolean isSpectating(UUID staffUUID) {
        return activeSpectators.containsKey(staffUUID);
    }

    public UUID getTarget(UUID staffUUID) {
        return activeSpectators.get(staffUUID);
    }

    public void onServerTick(MinecraftServer server) {
        if (activeSpectators.isEmpty()) return;

        activeSpectators.forEach((staffUUID, targetUUID) -> {
            ServerPlayerEntity staff  = server.getPlayerManager().getPlayer(staffUUID);
            ServerPlayerEntity target = server.getPlayerManager().getPlayer(targetUUID);
            if (staff == null || target == null) return;

            // Combat data from live session
            float reach = 0f, angle = 0f;
            boolean hasCombat = false;
            var liveSession = ExileFTW.dataLayer.getLiveSession(targetUUID);
            if (liveSession != null && !liveSession.records.isEmpty()) {
                var last = liveSession.records.get(liveSession.records.size() - 1);
                if (last.hasCombatEvent) {
                    reach = last.reachDistance;
                    angle = last.angleToTarget;
                    hasCombat = true;
                }
            }

            int suspicion = ExileFTW.suspicionTracker.getLevel(targetUUID);

            // Live data packet
            PacketChannel.LiveTickPayload dataPayload = new PacketChannel.LiveTickPayload(
                targetUUID,
                target.getX(), target.getY(), target.getZ(),
                target.getYaw(), target.getPitch(),
                target.getVelocity().x, target.getVelocity().y, target.getVelocity().z,
                target.getHealth(), target.getMaxHealth(),
                reach, angle, hasCombat, suspicion
            );
            ServerPlayNetworking.send(staff, dataPayload);

            // Camera POV packet — tells client to position camera at target's eye
            PacketChannel.CameraPovPayload camPayload = new PacketChannel.CameraPovPayload(
                target.getX(),
                target.getEyeY(),
                target.getZ(),
                target.getYaw(),
                target.getPitch()
            );
            ServerPlayNetworking.send(staff, camPayload);
        });
    }

    public void onStaffDisconnect(UUID staffUUID) {
        activeSpectators.remove(staffUUID);
    }
}
