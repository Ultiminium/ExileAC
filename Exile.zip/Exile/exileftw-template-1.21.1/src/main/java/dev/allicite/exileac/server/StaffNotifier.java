package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.UUID;

/**
 * Sends in-game alerts to all online staff when suspicion crosses thresholds.
 * Uses action bar messages so it doesn't interrupt chat.
 */
public class StaffNotifier {

    public static void notifySuspicionChange(MinecraftServer server, UUID playerUUID,
                                              String playerName, int oldLevel, int newLevel) {
        if (newLevel <= oldLevel) return;

        // Only notify on meaningful threshold crossings
        if (newLevel < 5) return;

        String message;
        Formatting color;

        if (newLevel >= 10) {
            message = "§c§l[ExileFTW] CERTAINTY: §f" + playerName + " §cis cheating (10/10)";
            color = Formatting.RED;
        } else if (newLevel >= 7 && oldLevel < 7) {
            message = "§6§l[ExileFTW] HIGH: §f" + playerName + " §6suspicion " + newLevel + "/10";
            color = Formatting.GOLD;
        } else if (newLevel >= 5 && oldLevel < 5) {
            message = "§e[ExileFTW] §f" + playerName + " §esuspicion " + newLevel + "/10 — worth watching";
            color = Formatting.YELLOW;
        } else {
            message = "§7[ExileFTW] §f" + playerName + " §7suspicion now " + newLevel + "/10";
            color = Formatting.GRAY;
        }

        for (ServerPlayerEntity staff : server.getPlayerManager().getPlayerList()) {
            if (server.getPlayerManager().isOperator(staff.getGameProfile())) {
                // Action bar — doesn't interrupt chat
                staff.sendMessage(Text.literal(message), true);
            }
        }

        ExileFTW.LOGGER.info("[ExileFTW] Staff notified: {} suspicion {} -> {}", playerName, oldLevel, newLevel);
    }
}
