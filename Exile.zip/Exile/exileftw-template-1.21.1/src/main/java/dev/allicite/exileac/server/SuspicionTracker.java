package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.network.PacketChannel;
import dev.allicite.exileac.server.data.ExileFile;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SuspicionTracker {

    private static final int BOT_THRESHOLD       = 10;
    private static final int PERSIST_THRESHOLD   = 6;
    private static final int ANALYSIS_INTERVAL   = 5;
    private static final int PUSH_INTERVAL_TICKS = 100;

    private final Map<UUID, Integer> suspicionLevels   = new ConcurrentHashMap<>();
    private final Map<UUID, String>  playerNames        = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> combatEventCounts  = new ConcurrentHashMap<>();
    private final VarianceEngine varianceEngine = new VarianceEngine();

    private int tickCounter = 0;
    private MinecraftServer serverRef = null;

    public void onServerTick(MinecraftServer server) {
        this.serverRef = server;
        tickCounter++;
        if (tickCounter % PUSH_INTERVAL_TICKS == 0) pushSuspicionMapToStaff(server);
    }

    public void onCombatEvent(UUID uuid, float reach, float angleDelta, int tick) {
        int count = combatEventCounts.merge(uuid, 1, Integer::sum);
        if (count % ANALYSIS_INTERVAL == 0) {
            ExileFile session = ExileFTW.dataLayer.getLiveSession(uuid);
            if (session != null && !session.records.isEmpty())
                varianceEngine.analyzeAsync(uuid, new ArrayList<>(session.records));
        }
    }

    public void setLevel(UUID uuid, int level) {
        int prev = suspicionLevels.getOrDefault(uuid, 0);
        suspicionLevels.put(uuid, level);
        ExileFTW.dataLayer.updateSuspicion(uuid, level);

        if (level >= BOT_THRESHOLD && prev < BOT_THRESHOLD)
            ExileFTW.botManager.spawnBotsFor(uuid);

        if (level != prev) {
            ExileFTW.LOGGER.info("[ExileFTW] {} suspicion {} -> {}", uuid, prev, level);
            // Staff notification on threshold crossings
            if (serverRef != null) {
                String name = playerNames.getOrDefault(uuid, uuid.toString().substring(0, 8));
                StaffNotifier.notifySuspicionChange(serverRef, uuid, name, prev, level);
            }
        }
    }

    public void trackPlayer(UUID uuid, String name) {
        playerNames.put(uuid, name);
        suspicionLevels.putIfAbsent(uuid, 0);
    }

    public int getLevel(UUID uuid) { return suspicionLevels.getOrDefault(uuid, 0); }

    public void clearPlayer(UUID uuid) {
        suspicionLevels.remove(uuid);
        combatEventCounts.remove(uuid);
        playerNames.remove(uuid);
    }

    public Map<UUID, Integer> getAllLevels() { return Collections.unmodifiableMap(suspicionLevels); }
    public Map<UUID, String>  getPlayerNames() { return Collections.unmodifiableMap(playerNames); }

    public void pushSuspicionMapToStaff(MinecraftServer server) {
        if (suspicionLevels.isEmpty()) return;
        List<PacketChannel.SuspicionEntry> entries = new ArrayList<>();
        suspicionLevels.forEach((uuid, level) -> {
            String name = playerNames.getOrDefault(uuid, uuid.toString().substring(0, 8));
            entries.add(new PacketChannel.SuspicionEntry(uuid, name, level));
        });
        PacketChannel.SuspicionMapPayload payload = new PacketChannel.SuspicionMapPayload(entries);
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (server.getPlayerManager().isOperator(player.getGameProfile()))
                ServerPlayNetworking.send(player, payload);
        }
    }
}
