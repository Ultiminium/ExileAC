package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.server.data.PlayerRecord;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TickRecorder {

    private final Map<UUID, PrevState> prevStates = new HashMap<>();
    private final Map<UUID, List<float[]>> subTickAimBuffer = new ConcurrentHashMap<>();

    public TickRecorder() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof ServerPlayerEntity player) onPlayerJoin(player);
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (entity instanceof ServerPlayerEntity player) onPlayerLeave(player);
        });
    }

    private void onPlayerJoin(ServerPlayerEntity player) {
        ExileFTW.dataLayer.startSession(player.getUuid());
        prevStates.put(player.getUuid(), new PrevState(player));
        subTickAimBuffer.put(player.getUuid(), new ArrayList<>());
        ExileFTW.suspicionTracker.trackPlayer(player.getUuid(), player.getName().getString());
    }

    private void onPlayerLeave(ServerPlayerEntity player) {
        int suspicion = ExileFTW.suspicionTracker.getLevel(player.getUuid());
        ExileFTW.dataLayer.endSession(player.getUuid(), suspicion);
        prevStates.remove(player.getUuid());
        subTickAimBuffer.remove(player.getUuid());
        ExileFTW.suspicionTracker.clearPlayer(player.getUuid());
        ExileFTW.botManager.removeBotsFor(player.getUuid());
        ExileFTW.velocityDetector.clearPlayer(player.getUuid());
        ExileFTW.backtrackDetector.clearPlayer(player.getUuid());
    }

    public void onRawMovementPacket(UUID uuid, float yaw, float pitch, int tick) {
        List<float[]> buf = subTickAimBuffer.get(uuid);
        if (buf != null) synchronized (buf) { buf.add(new float[]{yaw, pitch, tick}); }
    }

    public void onServerTick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            capturePlayerTick(player, server.getTicks());
            // Record position history for backtrack detection
            ExileFTW.backtrackDetector.recordPosition(player, server.getTicks());
        }
    }

    private void capturePlayerTick(ServerPlayerEntity player, int currentTick) {
        UUID uuid = player.getUuid();
        PrevState prev = prevStates.get(uuid);
        if (prev == null) { prevStates.put(uuid, new PrevState(player)); return; }

        byte flags = 0;
        if (player.isSprinting())    flags |= 0x01;
        if (player.handSwinging)     flags |= 0x04;
        if (player.isSneaking())     flags |= 0x08;
        if (player.isOnGround())     flags |= 0x10;
        if (player.isBlocking())     flags |= 0x20;

        boolean sprintReset = prev.sprinting && !player.isSprinting()
                && (Math.abs(player.getVelocity().x) > 0.01
                ||  Math.abs(player.getVelocity().z) > 0.01);
        boolean wTap = prev.velZ < -0.05 && player.getVelocity().z > 0.05;

        float health     = player.getHealth();
        float maxHealth  = player.getMaxHealth();
        float absorption = player.getAbsorptionAmount();

        float atkDmg  = getAttr(player, EntityAttributes.GENERIC_ATTACK_DAMAGE);
        float atkSpd  = getAttr(player, EntityAttributes.GENERIC_ATTACK_SPEED);
        float moveSpd = getAttr(player, EntityAttributes.GENERIC_MOVEMENT_SPEED);
        float armor   = getAttr(player, EntityAttributes.GENERIC_ARMOR);
        float armorT  = getAttr(player, EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        float kbRes   = getAttr(player, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);

        List<float[]> subTickSamples;
        List<float[]> buf = subTickAimBuffer.get(uuid);
        if (buf != null) {
            synchronized (buf) { subTickSamples = new ArrayList<>(buf); buf.clear(); }
        } else { subTickSamples = Collections.emptyList(); }

        PlayerRecord record = new PlayerRecord.Builder()
                .player(uuid)
                .tick(currentTick)
                .timestamp(System.currentTimeMillis())
                .pos(player.getX(), player.getY(), player.getZ())
                .orientation(player.getYaw(), player.getPitch())
                .velocity(player.getVelocity().x, player.getVelocity().y, player.getVelocity().z)
                .flags(flags)
                .hp(health, maxHealth, absorption)
                .attributes(atkDmg, atkSpd, moveSpd, armor, armorT, kbRes)
                .sprintReset(sprintReset)
                .wTap(wTap)
                .subTickAim(subTickSamples)
                .build();

        ExileFTW.dataLayer.appendRecord(uuid, record);
        prev.update(player);
    }

    private float getAttr(ServerPlayerEntity player, RegistryEntry<EntityAttribute> attr) {
        var instance = player.getAttributeInstance(attr);
        return instance != null ? (float) instance.getValue() : 0f;
    }

    private static class PrevState {
        boolean sprinting;
        double velX, velY, velZ;
        float yaw, pitch;

        PrevState(ServerPlayerEntity p) { update(p); }

        void update(ServerPlayerEntity p) {
            sprinting = p.isSprinting();
            velX  = p.getVelocity().x;
            velY  = p.getVelocity().y;
            velZ  = p.getVelocity().z;
            yaw   = p.getYaw();
            pitch = p.getPitch();
        }
    }
}
