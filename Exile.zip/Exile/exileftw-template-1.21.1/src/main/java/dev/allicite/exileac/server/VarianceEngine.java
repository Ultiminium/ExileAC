package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import dev.allicite.exileac.server.data.PlayerRecord;

import java.util.*;
import java.util.concurrent.*;

/**
 * Detection engine — async, never on tick thread.
 *
 * FALSE POSITIVE PHILOSOPHY:
 * A false positive ban is worse than a missed cheat.
 * Every threshold is tuned conservatively.
 * We only flag what is STATISTICALLY IMPOSSIBLE for a human.
 *
 * Triggerbot detection is DISABLED — too many false positives
 * from normal play (crits, combos, good aim).
 * It will be re-enabled when a more robust implementation exists.
 */
public class VarianceEngine {

    // Require many more samples before drawing conclusions
    private static final int   MIN_SAMPLES              = 20;

    // Reach — 3.3b is legitimate max with 100ms ping
    // We only flag well above this to avoid false positives
    private static final float REACH_VANILLA_MAX        = 3.3f;
    private static final float REACH_SUSPICIOUS_AVG     = 3.5f;  // raised from 3.4
    private static final float REACH_FLAG_AVG           = 3.8f;  // raised from 3.6
    private static final float REACH_OBVIOUS_AVG        = 4.5f;  // raised from 4.0

    // Aim — only flag extremely mechanical lock-on
    private static final float AIM_VARIANCE_THRESHOLD   = 0.02f; // tightened

    // Swap — zero variance sprint resets
    private static final float SWAP_VARIANCE_THRESHOLD  = 0.5f;

    // CPS — mechanical precision
    private static final float CPS_VARIANCE_THRESHOLD   = 2.0f;

    // Ping spoof
    private static final float PING_JITTER_MIN_HUMAN    = 2.0f;

    // Sequence thresholds — require more sequences
    private static final int   SEQ_THRESHOLD            = 5;

    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ExileFTW-Analysis"); t.setDaemon(true); return t;
    });

    public void analyzeAsync(UUID uuid, List<PlayerRecord> records) {
        executor.submit(() -> {
            try {
                AnalysisResult result = analyze(uuid, records);
                int level = computeLevel(result);
                ExileFTW.LOGGER.info("[ExileFTW] {} suspicion={} | {}", uuid, level, result.summary());
                ExileFTW.varianceLog.store(uuid, result);
                ExileFTW.suspicionTracker.setLevel(uuid, level);
            } catch (Exception e) {
                ExileFTW.LOGGER.error("[ExileFTW] Analysis failed for {}", uuid, e);
            }
        });
    }

    private AnalysisResult analyze(UUID uuid, List<PlayerRecord> records) {
        AnalysisResult r = new AnalysisResult(uuid);

        List<Integer> swapIntervals   = new ArrayList<>();
        List<Float>   aimDeltas       = new ArrayList<>();
        List<Float>   reachSamples    = new ArrayList<>();
        List<Integer> attackTicks     = new ArrayList<>();
        List<Float>   packetIntervals = new ArrayList<>();

        int lastSwapTick = -1;

        for (PlayerRecord rec : records) {
            if (rec.sprintResetThisTick || rec.wTapThisTick) {
                if (lastSwapTick >= 0) swapIntervals.add(rec.tick - lastSwapTick);
                lastSwapTick = rec.tick;
            }

            if (rec.subTickAimSamples != null && rec.subTickAimSamples.size() > 1) {
                for (int j = 1; j < rec.subTickAimSamples.size(); j++) {
                    float interval = (rec.subTickAimSamples.get(j)[2]
                                    - rec.subTickAimSamples.get(j-1)[2]) * 50f;
                    if (interval > 0) packetIntervals.add(interval);
                }
            }

            if (rec.hasCombatEvent) {
                aimDeltas.add(Math.abs(rec.angleToTarget));
                reachSamples.add(rec.reachDistance);
                attackTicks.add(rec.tick);
            }
        }

        // --- Reach ---
        if (reachSamples.size() >= MIN_SAMPLES) {
            r.reachSampleCount    = reachSamples.size();
            r.averageReach        = (float) reachSamples.stream().mapToDouble(Float::floatValue).average().orElse(0);
            r.maxReach            = reachSamples.stream().max(Float::compare).orElse(0f);
            r.reachVariance       = varianceF(reachSamples);
            r.hitsAboveVanillaMax = (int) reachSamples.stream().filter(v -> v > REACH_VANILLA_MAX).count();

            List<Float> extended = reachSamples.stream().filter(v -> v > REACH_SUSPICIOUS_AVG).toList();
            if (extended.size() >= 5) {
                r.extendedReachVariance = varianceF(new ArrayList<>(extended));
                r.extendedReachCount    = extended.size();
            }

            if (r.averageReach > REACH_FLAG_AVG) {
                ExileFTW.LOGGER.warn("[ExileFTW] REACH FLAG {} avg={}b max={}b",
                        uuid, String.format("%.3f", r.averageReach),
                        String.format("%.3f", r.maxReach));
                ExileFTW.warningLog.log(uuid, String.format(
                        "REACH: avg=%.3fb max=%.3fb %d/%d above %.1fb",
                        r.averageReach, r.maxReach,
                        r.hitsAboveVanillaMax, r.reachSampleCount, REACH_VANILLA_MAX));
            }
        }

        // --- Aim variance ---
        if (aimDeltas.size() >= MIN_SAMPLES) {
            r.aimDeltaVariance = varianceF(aimDeltas);
            r.aimSampleCount   = aimDeltas.size();
            r.aimLockSequences = countZeroVarSeqsF(aimDeltas, AIM_VARIANCE_THRESHOLD);
        }

        // --- Swap variance ---
        if (swapIntervals.size() >= MIN_SAMPLES) {
            r.swapIntervalVariance = variance(swapIntervals);
            r.swapSampleCount      = swapIntervals.size();
            if (r.swapIntervalVariance < SWAP_VARIANCE_THRESHOLD)
                r.zeroVarianceSwaps = countZeroVarSeqs(swapIntervals, SWAP_VARIANCE_THRESHOLD);
        }

        // --- CPS variance ---
        if (attackTicks.size() >= MIN_SAMPLES) {
            List<Integer> cpsIntervals = new ArrayList<>();
            for (int i = 1; i < attackTicks.size(); i++)
                cpsIntervals.add(attackTicks.get(i) - attackTicks.get(i-1));
            r.cpsIntervalVarianceMs = variance(cpsIntervals) * 50f;
            r.cpsSampleCount        = cpsIntervals.size();
            if (r.cpsIntervalVarianceMs < CPS_VARIANCE_THRESHOLD)
                r.zeroCpsVarianceSequences = countZeroVarSeqs(cpsIntervals, CPS_VARIANCE_THRESHOLD/50f);
        }

        // --- Ping spoof ---
        if (packetIntervals.size() >= 50) {
            r.packetJitterMs    = varianceF(packetIntervals);
            r.packetSampleCount = packetIntervals.size();
            if (r.packetJitterMs < PING_JITTER_MIN_HUMAN)
                ExileFTW.warningLog.log(uuid, String.format(
                        "PING_SPOOF: jitter=%.4fms over %d samples",
                        r.packetJitterMs, r.packetSampleCount));
        }

        return r;
    }

    private int computeLevel(AnalysisResult r) {
        double score = 0;

        // REACH — primary and most reliable signal
        if (r.reachSampleCount >= MIN_SAMPLES) {
            if      (r.averageReach > REACH_OBVIOUS_AVG)    score += 5.0;
            else if (r.averageReach > REACH_FLAG_AVG)        score += 3.0;
            else if (r.averageReach > REACH_SUSPICIOUS_AVG) score += 1.5;
            else if (r.averageReach > REACH_VANILLA_MAX)     score += 0.3;

            // Consistency of extended hits — cheat configured to specific value
            float aboveRatio = (float) r.hitsAboveVanillaMax / r.reachSampleCount;
            if (aboveRatio > 0.8f && r.hitsAboveVanillaMax >= 15) score += 2.0;
            else if (aboveRatio > 0.6f && r.hitsAboveVanillaMax >= 10) score += 1.0;

            if (r.extendedReachCount >= 8 && r.extendedReachVariance < 0.005f) score += 1.5;
            if (r.maxReach > 5.0f && r.hitsAboveVanillaMax >= 5) score += 2.0;
        }

        // PING SPOOF
        if (r.packetSampleCount >= 50) {
            if (r.packetJitterMs < 0.5f) score += 2.0;
            else if (r.packetJitterMs < PING_JITTER_MIN_HUMAN) score += 1.0;
        }

        // AIM LOCK — very tight threshold, many sequences required
        if (r.aimSampleCount >= MIN_SAMPLES) {
            if (r.aimLockSequences >= SEQ_THRESHOLD * 4) score += 2.0;
            else if (r.aimLockSequences >= SEQ_THRESHOLD * 2) score += 1.0;
        }

        // SWAP VARIANCE — mechanical macro pattern
        if (r.swapSampleCount >= MIN_SAMPLES) {
            if (r.zeroVarianceSwaps >= SEQ_THRESHOLD * 3) score += 2.0;
            else if (r.zeroVarianceSwaps >= SEQ_THRESHOLD) score += 0.5;
        }

        // CPS — very conservative
        if (r.cpsSampleCount >= MIN_SAMPLES) {
            if (r.zeroCpsVarianceSequences >= SEQ_THRESHOLD * 3) score += 1.0;
            else if (r.zeroCpsVarianceSequences >= SEQ_THRESHOLD * 2) score += 0.5;
        }

        return (int) Math.min(10, Math.round(score));
    }

    private float variance(List<Integer> v) {
        if (v.isEmpty()) return Float.MAX_VALUE;
        double mean = v.stream().mapToInt(Integer::intValue).average().orElse(0);
        return (float)(v.stream().mapToDouble(x -> (x-mean)*(x-mean)).sum() / v.size());
    }

    private float varianceF(List<Float> v) {
        if (v.isEmpty()) return Float.MAX_VALUE;
        double mean = v.stream().mapToDouble(Float::floatValue).average().orElse(0);
        return (float)(v.stream().mapToDouble(x -> (x-mean)*(x-mean)).sum() / v.size());
    }

    private int countZeroVarSeqs(List<Integer> v, float threshold) {
        int count = 0, w = Math.min(10, v.size());
        for (int i = 0; i <= v.size()-w; i++)
            if (variance(v.subList(i, i+w)) < threshold) count++;
        return count;
    }

    private int countZeroVarSeqsF(List<Float> v, float threshold) {
        int count = 0, w = Math.min(10, v.size());
        for (int i = 0; i <= v.size()-w; i++)
            if (varianceF(v.subList(i, i+w)) < threshold) count++;
        return count;
    }

    public static class AnalysisResult {
        public final UUID playerUUID;
        public float averageReach = 0f, maxReach = 0f, reachVariance = Float.MAX_VALUE;
        public float extendedReachVariance = Float.MAX_VALUE;
        public int   reachSampleCount, hitsAboveVanillaMax, extendedReachCount;
        public float aimDeltaVariance = Float.MAX_VALUE;
        public int   aimSampleCount, aimLockSequences;
        public float swapIntervalVariance = Float.MAX_VALUE;
        public int   swapSampleCount, zeroVarianceSwaps;
        public float cpsIntervalVarianceMs = Float.MAX_VALUE;
        public int   cpsSampleCount, zeroCpsVarianceSequences;
        public float avgTriggerbotDelay = Float.MAX_VALUE;
        public int   triggerbotSampleCount = 0, triggerbotFastFires = 0;
        public float packetJitterMs = Float.MAX_VALUE;
        public int   packetSampleCount;

        public AnalysisResult(UUID u) { this.playerUUID = u; }

        public String summary() {
            return String.format(
                "Reach avg=%.3f max=%.3f (%d above 3.3b) | AimVar=%.4f locks=%d | Jitter=%.4fms",
                averageReach, maxReach, hitsAboveVanillaMax,
                aimDeltaVariance, aimLockSequences, packetJitterMs);
        }
    }
}
