package dev.allicite.exileac.server;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores the latest VarianceEngine.AnalysisResult per player for inclusion in .exile exports.
 */
public class VarianceLog {

    private final Map<UUID, VarianceEngine.AnalysisResult> latest = new ConcurrentHashMap<>();

    public void store(UUID playerUUID, VarianceEngine.AnalysisResult result) {
        latest.put(playerUUID, result);
    }

    public VarianceEngine.AnalysisResult getLatest(UUID playerUUID) {
        return latest.get(playerUUID);
    }

    public void clearPlayer(UUID playerUUID) {
        latest.remove(playerUUID);
    }
}
