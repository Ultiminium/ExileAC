package dev.allicite.exileac.server;

import dev.allicite.exileac.ExileFTW;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Detects velocity manipulation (anti-knockback).
 *
 * How it works:
 * When a player is hit, the server applies knockback velocity.
 * We record what velocity the player SHOULD have next tick,
 * then compare it to what they actually report.
 *
 * A velocity cheat absorbs knockback — the player barely moves
 * after being hit despite the server applying force.
 *
 * Flags:
 *   - Received knockback but velocity didn't change as expected
 *   - Consistently absorbs >50% of expected knockback
 */
public class VelocityDetector {

    private static final float KB_ABSORPTION_THRESHOLD = 0.5f; // absorbing >50% = flag
    private static final int   MIN_KB_SAMPLES          = 5;

    // UUID -> expected velocity after knockback (set when hit is processed)
    private final Map<UUID, Vec3d> expectedVelocity = new ConcurrentHashMap<>();

    // UUID -> list of knockback absorption ratios
    private final Map<UUID, List<Float>> absorptionHistory = new ConcurrentHashMap<>();

    /**
     * Called when a player is hit and knockback is applied.
     * Records the expected next-tick velocity.
     */
    public void onKnockbackApplied(UUID playerUUID, Vec3d velocityAfterKnockback) {
        expectedVelocity.put(playerUUID, velocityAfterKnockback);
    }

    /**
     * Called every tick to compare actual velocity to expected.
     * Must be called AFTER the player's position/velocity has been updated.
     */
    public void checkVelocity(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        Vec3d expected = expectedVelocity.remove(uuid);
        if (expected == null) return;

        Vec3d actual = player.getVelocity();

        // Calculate how much of the knockback was absorbed
        double expectedMagnitude = expected.horizontalLength();
        double actualMagnitude   = actual.horizontalLength();

        if (expectedMagnitude < 0.01) return; // negligible knockback, skip

        // If actual velocity is much less than expected, knockback was absorbed
        double absorbed = Math.max(0, expectedMagnitude - actualMagnitude) / expectedMagnitude;

        absorptionHistory.computeIfAbsent(uuid, k -> new ArrayList<>()).add((float) absorbed);

        List<Float> history = absorptionHistory.get(uuid);

        if (history.size() >= MIN_KB_SAMPLES) {
            float avgAbsorption = (float) history.stream()
                    .mapToDouble(Float::floatValue).average().orElse(0);

            if (avgAbsorption > KB_ABSORPTION_THRESHOLD) {
                ExileFTW.LOGGER.warn(
                    "[ExileFTW] VELOCITY FLAG {}: absorbing {:.0f}% of knockback on average over {} hits",
                    player.getName().getString(),
                    avgAbsorption * 100,
                    history.size()
                );
                ExileFTW.warningLog.log(uuid, String.format(
                    "VELOCITY: absorbing %.0f%% of knockback (%d samples)",
                    avgAbsorption * 100, history.size()
                ));

                // Feed into suspicion — velocity cheat alone is worth +2-3
                int currentLevel = ExileFTW.suspicionTracker.getLevel(uuid);
                int boost = avgAbsorption > 0.8f ? 3 : 2;
                ExileFTW.suspicionTracker.setLevel(uuid, Math.min(10, currentLevel + boost));
            }

            // Keep history window at 20 samples
            if (history.size() > 20) history.remove(0);
        }
    }

    public void clearPlayer(UUID uuid) {
        expectedVelocity.remove(uuid);
        absorptionHistory.remove(uuid);
    }
}
