package dev.allicite.exileac.server;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores ExileFTW warning messages per player for inclusion in .exile exports.
 */
public class WarningLog {

    private final Map<UUID, List<String>> logs = new ConcurrentHashMap<>();
    private static final int MAX_LOGS_PER_PLAYER = 500;

    public void log(UUID playerUUID, String message) {
        logs.computeIfAbsent(playerUUID, k -> new ArrayList<>());
        List<String> playerLogs = logs.get(playerUUID);
        synchronized (playerLogs) {
            if (playerLogs.size() < MAX_LOGS_PER_PLAYER) {
                playerLogs.add("[" + System.currentTimeMillis() + "] " + message);
            }
        }
    }

    public List<String> getLogsFor(UUID playerUUID) {
        List<String> playerLogs = logs.get(playerUUID);
        if (playerLogs == null) return Collections.emptyList();
        synchronized (playerLogs) {
            return new ArrayList<>(playerLogs);
        }
    }

    public void clearPlayer(UUID playerUUID) {
        logs.remove(playerUUID);
    }
}
