package dev.allicite.exileac.server.data;

import dev.allicite.exileac.ExileFTW;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Manages all .exile session files.
 * Writes variance data into the session on flush.
 */
public class ExileDataLayer {

    private static final Path DATA_ROOT = Path.of("exile-data");
    private static final int  PERSIST_THRESHOLD = 6;

    private final Map<UUID, ExileFile> sessionBuffer = new ConcurrentHashMap<>();
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ExileFTW-IO");
        t.setDaemon(true);
        return t;
    });

    public ExileDataLayer() {
        try { Files.createDirectories(DATA_ROOT); }
        catch (IOException e) { ExileFTW.LOGGER.error("[ExileFTW] Failed to create exile-data dir", e); }
    }

    public void startSession(UUID uuid) {
        sessionBuffer.put(uuid, new ExileFile(uuid, System.currentTimeMillis()));
    }

    public void endSession(UUID uuid, int suspicionLevel) {
        ExileFile session = sessionBuffer.remove(uuid);
        if (session == null) return;
        if (suspicionLevel > PERSIST_THRESHOLD) {
            session.suspicionLevel = (byte) suspicionLevel;
            injectVarianceAndWrite(uuid, session);
        }
    }

    public void appendRecord(UUID uuid, PlayerRecord record) {
        ExileFile session = sessionBuffer.get(uuid);
        if (session != null) session.records.add(record);
    }

    public void updateSuspicion(UUID uuid, int level) {
        ExileFile session = sessionBuffer.get(uuid);
        if (session == null) return;
        session.suspicionLevel = (byte) level;
        if (level > PERSIST_THRESHOLD) writeAsync(snapshot(session, uuid));
    }

    public List<ExileFile> loadSessions(UUID uuid) {
        List<ExileFile> result = new ArrayList<>();
        Path dir = DATA_ROOT.resolve(uuid.toString());
        if (!Files.exists(dir)) return result;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.exile")) {
            for (Path p : stream) {
                try { result.add(ExileFile.deserialize(Files.readAllBytes(p))); }
                catch (IOException e) { ExileFTW.LOGGER.warn("[ExileFTW] Failed to read {}", p); }
            }
        } catch (IOException e) { ExileFTW.LOGGER.error("[ExileFTW] Failed to list sessions for {}", uuid, e); }
        result.sort(Comparator.comparingLong(f -> f.sessionStartMs));
        return result;
    }

    public ExileFile getLiveSession(UUID uuid) { return sessionBuffer.get(uuid); }

    public void flushAll() {
        sessionBuffer.forEach((uuid, session) -> {
            if (session.suspicionLevel > PERSIST_THRESHOLD) {
                try { writeToDisk(injectVariance(uuid, session)); }
                catch (IOException e) { ExileFTW.LOGGER.error("[ExileFTW] Flush failed for {}", uuid, e); }
            }
        });
        ioExecutor.shutdown();
    }

    /** Inject variance data from VarianceLog into session before writing. */
    private ExileFile injectVariance(UUID uuid, ExileFile file) {
        var result = ExileFTW.varianceLog.getLatest(uuid);
        if (result != null) {
            ExileFile.VarianceSnapshot vs = new ExileFile.VarianceSnapshot();
            vs.swapIntervalVariance      = result.swapIntervalVariance;
            vs.swapSampleCount           = result.swapSampleCount;
            vs.zeroVarianceSwaps         = result.zeroVarianceSwaps;
            vs.aimDeltaVariance          = result.aimDeltaVariance;
            vs.aimSampleCount            = result.aimSampleCount;
            vs.aimLockSequences          = result.aimLockSequences;
            vs.reachVariance             = result.reachVariance;
            vs.averageReach              = result.averageReach;
            vs.maxReach                  = result.maxReach;
            vs.reachSampleCount          = result.reachSampleCount;
            vs.hitsAboveVanillaMax       = result.hitsAboveVanillaMax;
            vs.cpsIntervalVarianceMs     = result.cpsIntervalVarianceMs;
            vs.cpsSampleCount            = result.cpsSampleCount;
            vs.zeroCpsVarianceSequences  = result.zeroCpsVarianceSequences;
            vs.avgTriggerbotDelay        = result.avgTriggerbotDelay;
            vs.triggerbotSampleCount     = result.triggerbotSampleCount;
            vs.triggerbotFastFires       = result.triggerbotFastFires;
            vs.packetJitterMs            = result.packetJitterMs;
            vs.packetSampleCount         = result.packetSampleCount;
            file.variance = vs;
        }
        // Inject server logs
        file.serverLogs.addAll(ExileFTW.warningLog.getLogsFor(uuid));
        // Populate combat log from tick records
        for (PlayerRecord rec : file.records) {
            if (rec.hasCombatEvent && rec.targetUUID != null) {
                file.combatLog.add(new ExileFile.CombatEntry(
                    rec.tick, rec.targetUUID, rec.reachDistance,
                    rec.angleToTarget, rec.pitchToTarget,
                    rec.hitRegistered, rec.stateFlags));
            }
        }
        return file;
    }

    private void injectVarianceAndWrite(UUID uuid, ExileFile session) {
        writeAsync(injectVariance(uuid, session));
    }

    private ExileFile snapshot(ExileFile src, UUID uuid) {
        ExileFile s = new ExileFile(src.playerUUID, src.sessionStartMs);
        s.suspicionLevel = src.suspicionLevel;
        s.records.addAll(src.records);
        return injectVariance(uuid, s);
    }

    private void writeAsync(ExileFile file) {
        ioExecutor.submit(() -> {
            try { writeToDisk(file); }
            catch (IOException e) { ExileFTW.LOGGER.error("[ExileFTW] Async write failed for {}", file.playerUUID, e); }
        });
    }

    private void writeToDisk(ExileFile file) throws IOException {
        Path dir = DATA_ROOT.resolve(file.playerUUID.toString());
        Files.createDirectories(dir);
        Path path = dir.resolve(file.sessionStartMs + ".exile");
        Files.write(path, file.serialize(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        ExileFTW.LOGGER.info("[ExileFTW] Wrote {} records -> {}", file.records.size(), path);
    }
}
