package dev.allicite.exileac.server.data;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.zip.CRC32;

/**
 * Full .exile replay format v2.
 * Includes tick records, combat log, packet log, variance snapshot, server logs.
 */
public class ExileFile {

    public static final byte[] MAGIC = {0x45, 0x58, 0x49, 0x4C, 0x45};
    public static final byte FORMAT_VERSION = 0x02;

    public UUID   playerUUID;
    public long   sessionStartMs;
    public byte   suspicionLevel;
    public String serverName = "Unknown";

    public List<PlayerRecord> records    = new ArrayList<>();
    public List<CombatEntry>  combatLog  = new ArrayList<>();
    public List<PacketEntry>  packetLog  = new ArrayList<>();
    public List<String>       serverLogs = new ArrayList<>();
    public VarianceSnapshot   variance   = null;

    public ExileFile(UUID playerUUID, long sessionStartMs) {
        this.playerUUID     = playerUUID;
        this.sessionStartMs = sessionStartMs;
    }

    public record CombatEntry(
        int tick, UUID targetUUID, float reach,
        float angleToTarget, float pitchToTarget,
        boolean hitRegistered, byte stateFlags) {}

    public record PacketEntry(int tick, float yaw, float pitch) {}

    public static class VarianceSnapshot {
        public float swapIntervalVariance   = Float.MAX_VALUE;
        public int   swapSampleCount;
        public int   zeroVarianceSwaps;
        public float aimDeltaVariance       = Float.MAX_VALUE;
        public int   aimSampleCount;
        public int   aimLockSequences;
        public float reachVariance          = Float.MAX_VALUE;
        public float averageReach;
        public float maxReach;
        public int   reachSampleCount;
        public int   hitsAboveVanillaMax;
        public float cpsIntervalVarianceMs  = Float.MAX_VALUE;
        public int   cpsSampleCount;
        public int   zeroCpsVarianceSequences;
        public float avgTriggerbotDelay     = Float.MAX_VALUE;
        public int   triggerbotSampleCount;
        public int   triggerbotFastFires;
        public float packetJitterMs         = Float.MAX_VALUE;
        public int   packetSampleCount;
    }

    public byte[] serialize() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        dos.write(MAGIC);
        dos.write(FORMAT_VERSION);
        dos.writeLong(playerUUID.getMostSignificantBits());
        dos.writeLong(playerUUID.getLeastSignificantBits());
        dos.writeLong(sessionStartMs);
        dos.write(suspicionLevel);
        dos.writeInt(records.size());
        dos.writeInt(combatLog.size());
        dos.writeInt(packetLog.size());
        dos.writeInt(serverLogs.size());

        byte[] nameBytes = serverName.getBytes(StandardCharsets.UTF_8);
        byte[] namePadded = new byte[15];
        System.arraycopy(nameBytes, 0, namePadded, 0, Math.min(nameBytes.length, 15));
        dos.write(namePadded);
        dos.write(0); // reserved

        // Tick records
        for (PlayerRecord r : records) {
            dos.writeInt(r.tick);
            dos.writeDouble(r.posX); dos.writeDouble(r.posY); dos.writeDouble(r.posZ);
            dos.writeFloat(r.yaw);   dos.writeFloat(r.pitch);
            dos.writeDouble(r.velX); dos.writeDouble(r.velY); dos.writeDouble(r.velZ);
            dos.write(r.stateFlags);
            dos.write(r.hasCombatEvent ? 1 : 0);
            long tMsb = r.targetUUID != null ? r.targetUUID.getMostSignificantBits() : 0L;
            long tLsb = r.targetUUID != null ? r.targetUUID.getLeastSignificantBits() : 0L;
            dos.writeLong(tMsb); dos.writeLong(tLsb);
            dos.writeFloat(r.reachDistance);
            dos.writeFloat(r.angleToTarget);
            dos.writeFloat(r.pitchToTarget);
            dos.write(r.hitRegistered ? 1 : 0);
            dos.write(r.sprintResetThisTick ? 1 : 0);
            dos.write(r.wTapThisTick ? 1 : 0);
            dos.writeInt(0);
        }

        // Combat log
        for (CombatEntry c : combatLog) {
            dos.writeInt(c.tick());
            dos.writeLong(c.targetUUID().getMostSignificantBits());
            dos.writeLong(c.targetUUID().getLeastSignificantBits());
            dos.writeFloat(c.reach());
            dos.writeFloat(c.angleToTarget());
            dos.writeFloat(c.pitchToTarget());
            dos.write(c.hitRegistered() ? 1 : 0);
            dos.write(c.stateFlags());
            dos.writeInt(0); dos.writeInt(0); dos.writeInt(0);
        }

        // Packet log
        for (PacketEntry p : packetLog) {
            dos.writeInt(p.tick());
            dos.writeFloat(p.yaw());
            dos.writeFloat(p.pitch());
        }

        // Variance snapshot
        if (variance != null) {
            dos.write(1);
            dos.writeFloat(variance.swapIntervalVariance);
            dos.writeInt(variance.swapSampleCount);
            dos.writeInt(variance.zeroVarianceSwaps);
            dos.writeFloat(variance.aimDeltaVariance);
            dos.writeInt(variance.aimSampleCount);
            dos.writeInt(variance.aimLockSequences);
            dos.writeFloat(variance.reachVariance);
            dos.writeFloat(variance.averageReach);
            dos.writeFloat(variance.maxReach);
            dos.writeInt(variance.reachSampleCount);
            dos.writeInt(variance.hitsAboveVanillaMax);
            dos.writeFloat(variance.cpsIntervalVarianceMs);
            dos.writeInt(variance.cpsSampleCount);
            dos.writeInt(variance.zeroCpsVarianceSequences);
            dos.writeFloat(variance.avgTriggerbotDelay);
            dos.writeInt(variance.triggerbotSampleCount);
            dos.writeInt(variance.triggerbotFastFires);
            dos.writeFloat(variance.packetJitterMs);
            dos.writeInt(variance.packetSampleCount);
        } else {
            dos.write(0);
            dos.write(new byte[76]); // padding
        }

        // Server logs
        for (String log : serverLogs) {
            byte[] lb = log.getBytes(StandardCharsets.UTF_8);
            dos.writeShort(lb.length);
            dos.write(lb);
        }

        dos.flush();
        byte[] data = baos.toByteArray();

        CRC32 crc = new CRC32();
        crc.update(data);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(data);
        new DataOutputStream(out).writeInt((int) crc.getValue());
        return out.toByteArray();
    }

    public static ExileFile deserialize(byte[] data) throws IOException {
        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(data));

        byte[] magic = new byte[5];
        dis.readFully(magic);
        for (int i = 0; i < MAGIC.length; i++)
            if (magic[i] != MAGIC[i]) throw new IOException("Invalid .exile file");

        byte version = dis.readByte();
        if (version != FORMAT_VERSION && version != 0x01)
            throw new IOException("Unsupported version: " + version);

        UUID uuid = new UUID(dis.readLong(), dis.readLong());
        long sessionStartMs = dis.readLong();
        ExileFile file = new ExileFile(uuid, sessionStartMs);
        file.suspicionLevel = dis.readByte();

        int recordCount = dis.readInt();
        int combatCount = dis.readInt();
        int packetCount = dis.readInt();
        int logCount    = dis.readInt();

        byte[] nameBytes = new byte[15];
        dis.readFully(nameBytes);
        file.serverName = new String(nameBytes, StandardCharsets.UTF_8).trim().replace("\0", "");
        dis.readByte();

        // Tick records
        for (int i = 0; i < recordCount; i++) {
            PlayerRecord.Builder b = new PlayerRecord.Builder();
            b.player(uuid).tick(dis.readInt());
            b.pos(dis.readDouble(), dis.readDouble(), dis.readDouble());
            b.orientation(dis.readFloat(), dis.readFloat());
            b.velocity(dis.readDouble(), dis.readDouble(), dis.readDouble());
            b.flags(dis.readByte());
            boolean hasCombat = dis.readByte() == 1;
            UUID tUUID = new UUID(dis.readLong(), dis.readLong());
            float reach = dis.readFloat(), angle = dis.readFloat(), pd = dis.readFloat();
            boolean hit = dis.readByte() == 1;
            boolean sr  = dis.readByte() == 1;
            boolean wt  = dis.readByte() == 1;
            dis.readInt();
            if (hasCombat) b.combat(tUUID, reach, angle, pd, hit);
            b.sprintReset(sr).wTap(wt).timestamp(sessionStartMs + (i * 50L));
            file.records.add(b.build());
        }

        // Combat log
        for (int i = 0; i < combatCount; i++) {
            int tick = dis.readInt();
            UUID tUUID = new UUID(dis.readLong(), dis.readLong());
            float reach = dis.readFloat(), angle = dis.readFloat(), pitch = dis.readFloat();
            boolean hit = dis.readByte() == 1;
            byte flags  = dis.readByte();
            dis.readInt(); dis.readInt(); dis.readInt();
            file.combatLog.add(new CombatEntry(tick, tUUID, reach, angle, pitch, hit, flags));
        }

        // Packet log
        for (int i = 0; i < packetCount; i++) {
            int tick = dis.readInt();
            float yaw = dis.readFloat(), p = dis.readFloat();
            file.packetLog.add(new PacketEntry(tick, yaw, p));
        }

        // Variance snapshot
        byte hasVariance = dis.readByte();
        byte[] varPad = new byte[76];
        dis.readFully(varPad);
        if (hasVariance == 1) {
            DataInputStream vd = new DataInputStream(new ByteArrayInputStream(varPad));
            VarianceSnapshot vs = new VarianceSnapshot();
            vs.swapIntervalVariance      = vd.readFloat();
            vs.swapSampleCount           = vd.readInt();
            vs.zeroVarianceSwaps         = vd.readInt();
            vs.aimDeltaVariance          = vd.readFloat();
            vs.aimSampleCount            = vd.readInt();
            vs.aimLockSequences          = vd.readInt();
            vs.reachVariance             = vd.readFloat();
            vs.averageReach              = vd.readFloat();
            vs.maxReach                  = vd.readFloat();
            vs.reachSampleCount          = vd.readInt();
            vs.hitsAboveVanillaMax       = vd.readInt();
            vs.cpsIntervalVarianceMs     = vd.readFloat();
            vs.cpsSampleCount            = vd.readInt();
            vs.zeroCpsVarianceSequences  = vd.readInt();
            vs.avgTriggerbotDelay        = vd.readFloat();
            vs.triggerbotSampleCount     = vd.readInt();
            vs.triggerbotFastFires       = vd.readInt();
            vs.packetJitterMs            = vd.readFloat();
            vs.packetSampleCount         = vd.readInt();
            file.variance = vs;
        }

        // Server logs
        for (int i = 0; i < logCount; i++) {
            int len = dis.readShort() & 0xFFFF;
            byte[] lb = new byte[len];
            dis.readFully(lb);
            file.serverLogs.add(new String(lb, StandardCharsets.UTF_8));
        }

        return file;
    }
}
