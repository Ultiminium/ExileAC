package dev.allicite.exileac.server.data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlayerRecord {

    public final UUID playerUUID;
    public final int tick;
    public final long timestampMs;
    public final double posX, posY, posZ;
    public final float yaw, pitch;
    public final double velX, velY, velZ;
    public final byte stateFlags;

    // Health
    public final float health;
    public final float maxHealth;
    public final float absorptionAmount;

    // Attributes
    public final float attackDamage;
    public final float attackSpeed;
    public final float movementSpeed;
    public final float armor;
    public final float armorToughness;
    public final float knockbackResist;

    // Combat
    public final boolean hasCombatEvent;
    public final UUID targetUUID;
    public final float reachDistance;
    public final float angleToTarget;
    public final float pitchToTarget;
    public final boolean hitRegistered;

    // Technique
    public final boolean sprintResetThisTick;
    public final boolean wTapThisTick;
    public final List<float[]> subTickAimSamples;

    private PlayerRecord(Builder b) {
        this.playerUUID       = b.playerUUID;
        this.tick             = b.tick;
        this.timestampMs      = b.timestampMs;
        this.posX = b.posX; this.posY = b.posY; this.posZ = b.posZ;
        this.yaw = b.yaw;   this.pitch = b.pitch;
        this.velX = b.velX; this.velY = b.velY; this.velZ = b.velZ;
        this.stateFlags       = b.stateFlags;
        this.health           = b.health;
        this.maxHealth        = b.maxHealth;
        this.absorptionAmount = b.absorptionAmount;
        this.attackDamage     = b.attackDamage;
        this.attackSpeed      = b.attackSpeed;
        this.movementSpeed    = b.movementSpeed;
        this.armor            = b.armor;
        this.armorToughness   = b.armorToughness;
        this.knockbackResist  = b.knockbackResist;
        this.hasCombatEvent   = b.hasCombatEvent;
        this.targetUUID       = b.targetUUID;
        this.reachDistance    = b.reachDistance;
        this.angleToTarget    = b.angleToTarget;
        this.pitchToTarget    = b.pitchToTarget;
        this.hitRegistered    = b.hitRegistered;
        this.sprintResetThisTick = b.sprintResetThisTick;
        this.wTapThisTick     = b.wTapThisTick;
        this.subTickAimSamples = b.subTickAimSamples != null ? b.subTickAimSamples : new ArrayList<>();
    }

    public double getBPS() { return Math.sqrt(velX * velX + velZ * velZ) * 20.0; }
    public float getHearts()    { return health / 2f; }
    public float getMaxHearts() { return maxHealth / 2f; }

    public boolean isSprinting() { return (stateFlags & 0x01) != 0; }
    public boolean isSwinging()  { return (stateFlags & 0x04) != 0; }
    public boolean isSneaking()  { return (stateFlags & 0x08) != 0; }
    public boolean isOnGround()  { return (stateFlags & 0x10) != 0; }
    public boolean isBlocking()  { return (stateFlags & 0x20) != 0; }

    public static class Builder {
        private UUID playerUUID;
        private int tick;
        private long timestampMs;
        private double posX, posY, posZ;
        private float yaw, pitch;
        private double velX, velY, velZ;
        private byte stateFlags;
        private float health, maxHealth, absorptionAmount;
        private float attackDamage, attackSpeed, movementSpeed;
        private float armor, armorToughness, knockbackResist;
        private boolean hasCombatEvent;
        private UUID targetUUID;
        private float reachDistance, angleToTarget, pitchToTarget;
        private boolean hitRegistered;
        private boolean sprintResetThisTick;
        private boolean wTapThisTick;
        private List<float[]> subTickAimSamples;

        public Builder player(UUID u)    { this.playerUUID = u; return this; }
        public Builder tick(int t)       { this.tick = t; return this; }
        public Builder timestamp(long ms){ this.timestampMs = ms; return this; }
        public Builder pos(double x, double y, double z) { posX=x;posY=y;posZ=z; return this; }
        public Builder orientation(float y, float p) { this.yaw=y;this.pitch=p; return this; }
        public Builder velocity(double vx, double vy, double vz) { velX=vx;velY=vy;velZ=vz; return this; }
        public Builder flags(byte f)     { this.stateFlags=f; return this; }
        // Named hp() to avoid conflict with future method overloading
        public Builder hp(float hp, float maxHp, float absorption) {
            this.health=hp; this.maxHealth=maxHp; this.absorptionAmount=absorption; return this;
        }
        public Builder attributes(float atkDmg, float atkSpd, float moveSpd,
                                  float armor, float armorTough, float kbResist) {
            this.attackDamage=atkDmg; this.attackSpeed=atkSpd; this.movementSpeed=moveSpd;
            this.armor=armor; this.armorToughness=armorTough; this.knockbackResist=kbResist;
            return this;
        }
        public Builder combat(UUID target, float reach, float angle, float pitchDelta, boolean hit) {
            this.hasCombatEvent=true; this.targetUUID=target;
            this.reachDistance=reach; this.angleToTarget=angle;
            this.pitchToTarget=pitchDelta; this.hitRegistered=hit;
            return this;
        }
        public Builder sprintReset(boolean v)      { this.sprintResetThisTick=v; return this; }
        public Builder wTap(boolean v)             { this.wTapThisTick=v; return this; }
        public Builder subTickAim(List<float[]> s) { this.subTickAimSamples=s; return this; }
        public PlayerRecord build() { return new PlayerRecord(this); }
    }
}
